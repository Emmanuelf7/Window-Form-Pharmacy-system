﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmProductReportView : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        public frmProductReportView()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
        }

        private void frmProductReportView_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }



        public void LoadProductReport(string query, string search)
        {
            using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
            {
                cn.Open();
                using (SqlCommand cmd = new SqlCommand(query, cn))
                {
                    if (!string.IsNullOrEmpty(search))
                    {
                        cmd.Parameters.AddWithValue("@search", "%" + search + "%");
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds, "dtProduct");

                    // 🔹 Set Report Path FIRST
                    this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptProduct.rdlc";

                    // 🔹 Clear old sources and bind fresh dataset
                    this.reportViewer1.LocalReport.DataSources.Clear();

                    // ⚠️ IMPORTANT: "DataSet1" (or whatever is inside the RDLC dataset name) must match
                    ReportDataSource rds = new ReportDataSource("DataSet", ds.Tables["dtProduct"]);
                    this.reportViewer1.LocalReport.DataSources.Add(rds);

                    this.reportViewer1.RefreshReport();
                }
            }
        }


       

    }
}
