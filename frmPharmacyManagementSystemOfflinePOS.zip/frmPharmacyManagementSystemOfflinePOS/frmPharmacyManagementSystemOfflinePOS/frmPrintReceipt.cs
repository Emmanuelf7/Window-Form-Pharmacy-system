﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmPrintReceipt : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        string store = "Divine Health Pharmacy";
        string address = "Madina La-nkwatannang Council";
        string phone = "Phone #: 055 735 2943";
        frmSales f;
        public frmPrintReceipt(frmSales fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            f = fm;
        }

        private void frmPrintReceipt_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }


        public void LoadReport(string pTendered, string pBalance)
        {
            ReportDataSource rptReportDataSource;
            try
            {
                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptReceipt.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();

                DataSet ds = new DataSet();

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    string query = @"
                SELECT 
                    s.SalesID, 
                    s.InvoiceNo, 
                    s.ProductID, 
                    b.Brand, 
                    g.Generic, 
                    c.Classification, 
                    t.TypeName, 
                    f.FormulationName, 
                    s.Price, 
                    s.Qty, 
                    s.Discount, 
                    s.LineTotal, 
                    sd.SalesDate 
                FROM tblSales s 
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo 
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID 
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID 
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId 
                LEFT JOIN tblType t ON s.TypeId = t.TypeID 
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID 
                WHERE s.InvoiceNo = @invoiceNo";

                    SqlDataAdapter da = new SqlDataAdapter(query, cn);

                    // ✅ Add parameter correctly
                    da.SelectCommand.Parameters.Add("@invoiceNo", SqlDbType.VarChar).Value = f.lblIvoiceNo.Text.Trim();

                    // ✅ Fill dataset and create dtReceipt table automatically
                    da.Fill(ds,"dtReceipt");
                }

                // Report parameters
                ReportParameter pVat = new ReportParameter("pVat", f.lblVat.Text);
                ReportParameter pDiscount = new ReportParameter("pDiscount", f.lblDiscount.Text);
                ReportParameter pTotal = new ReportParameter("pTotal", f.lblSubTotal.Text);
                ReportParameter rpTendered = new ReportParameter("pTendered", pTendered);
                ReportParameter rpBalance = new ReportParameter("pBalance", pBalance);
 
                ReportParameter pStore = new ReportParameter("pStore", store);
                ReportParameter pAddress = new ReportParameter("pAddress", address);
                ReportParameter pPhoneNo = new ReportParameter("pPhoneNo", phone);
                ReportParameter pInvoiceNo = new ReportParameter("pInvoiceNo", "Receipt #: "+f.lblIvoiceNo.Text);
                ReportParameter pCashier = new ReportParameter("pCashier", f.lblUser.Text);

               
                // ✅ Assign parameters one by one
                reportViewer1.LocalReport.SetParameters(pVat);
                reportViewer1.LocalReport.SetParameters(pDiscount);
                reportViewer1.LocalReport.SetParameters(pTotal);
                reportViewer1.LocalReport.SetParameters(rpTendered);
                reportViewer1.LocalReport.SetParameters(rpBalance);
                reportViewer1.LocalReport.SetParameters(pStore);
                reportViewer1.LocalReport.SetParameters(pAddress);
                reportViewer1.LocalReport.SetParameters(pPhoneNo);
                reportViewer1.LocalReport.SetParameters(pInvoiceNo);
                reportViewer1.LocalReport.SetParameters(pCashier);

                // ✅ Add datasource
                rptReportDataSource = new ReportDataSource("DataSet", ds.Tables["dtReceipt"]);
                reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);

                // ✅ Viewer display setup
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;


                // ✅ Bind dataset
                rptReportDataSource = new ReportDataSource("DataSet", ds.Tables["dtReceipt"]);
                reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);

                // Report viewer settings
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


    }
}
