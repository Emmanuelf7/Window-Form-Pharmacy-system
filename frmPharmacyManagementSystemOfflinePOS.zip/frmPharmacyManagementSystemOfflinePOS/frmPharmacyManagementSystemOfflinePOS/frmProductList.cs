﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmProductList : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
       // SqlDataReader dr;
        public frmProductList()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadProducts();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            frm_Product frm = new frm_Product(this);
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            frm.Show();

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit1")
            {
                frm_Product frm = new frm_Product(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblProductID.Text = dataGridView2[1, e.RowIndex].Value.ToString();
                frm.txt_Barcode.Text = dataGridView2[2, e.RowIndex].Value.ToString();
                frm.txt_Brand.Text = dataGridView2[3, e.RowIndex].Value.ToString();
                frm.txt_Generic.Text = dataGridView2[4, e.RowIndex].Value.ToString();
                frm.txt_Classification.Text = dataGridView2[5, e.RowIndex].Value.ToString();
                frm.txt_Type.Text = dataGridView2[6, e.RowIndex].Value.ToString();
                frm.txt_Formulation.Text = dataGridView2[7, e.RowIndex].Value.ToString();
                frm.txt_InitialQtyLevel.Text = dataGridView2[8, e.RowIndex].Value.ToString();
                frm.txt_CostPrice.Text = dataGridView2[9, e.RowIndex].Value.ToString();
                frm.txt_SellingPrice.Text = dataGridView2[11, e.RowIndex].Value.ToString();
                frm.profit =Convert.ToDecimal(dataGridView2[12, e.RowIndex].Value.ToString());
                frm.dtExpiringDate.CustomFormat = dataGridView2[13, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete1")
            {
                if (MessageBox.Show("Please confirm if you want to delete this brand!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblProducts where ProductID like '" + dataGridView2[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Brand has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadProducts();
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmProductList_Load(object sender, EventArgs e)
        {

        }



        public void LoadProducts()
        {
            try
            {
                int i = 0;
                dataGridView2.Rows.Clear();
                cn.Open();

                string query = @"
            SELECT 
                p.ProductID,
                p.Barcode,
                b.Brand,
                g.Generic,
                c.Classification,
                t.TypeName,
                f.FormulationName,
                p.Qty,  -- Current stock
                ISNULL(si.TotalStockIn, 0) AS StockInQty,  -- Total received stock
                p.CostPrice,
                p.SellingPrice,
                p.Profit,
                p.ExpiringDate
            FROM tblProducts AS p
            INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
            INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
            INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
            INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
            INNER JOIN tblType AS t ON p.TypeId = t.TypeID
            LEFT JOIN (
                SELECT productId, SUM(StockInQty) AS TotalStockIn
                FROM tblStockIn
                GROUP BY productId
            ) AS si ON p.ProductID = si.productId
            ORDER BY p.ProductID";

                using (SqlCommand cm = new SqlCommand(query, cn))
                using (SqlDataReader dr = cm.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        i++;
                        DateTime fDate = Convert.ToDateTime(dr["ExpiringDate"]);
                        string formattedFDate = fDate.ToString("dd/MM/yyyy");

                        dataGridView2.Rows.Add(
                            i,
                            dr["ProductID"].ToString(),
                            dr["Barcode"].ToString(),
                            dr["Brand"].ToString(),
                            dr["Generic"].ToString(),
                            dr["Classification"].ToString(),
                            dr["TypeName"].ToString(),
                            dr["FormulationName"].ToString(),
                            dr["Qty"].ToString(),                              // Current stock
                            double.Parse(dr["CostPrice"].ToString()).ToString("#,##0.0"),
                            dr["StockInQty"].ToString(),                       // Total received
                            double.Parse(dr["SellingPrice"].ToString()).ToString("#,##0.0"),
                            double.Parse(dr["Profit"].ToString()).ToString("#,##0.0"),
                            formattedFDate
                        );
                    }
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frm_StockIn frm = new frm_StockIn();
            frm.Loadproduct();
            frm.Show();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int i = 0;
                dataGridView2.Rows.Clear();
                cn.Open();

                string query = @"
            SELECT 
                p.ProductID,
                p.Barcode,
                b.Brand,
                g.Generic,
                c.Classification,
                t.TypeName,
                f.FormulationName,
                p.Qty,  -- Current stock
                ISNULL(si.TotalStockIn, 0) AS StockInQty,  -- Total received stock
                p.CostPrice,
                p.SellingPrice,
                p.Profit,
                p.ExpiringDate
            FROM tblProducts AS p
            INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
            INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
            INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
            INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
            INNER JOIN tblType AS t ON p.TypeId = t.TypeID
            LEFT JOIN (
                SELECT productId, SUM(StockInQty) AS TotalStockIn
                FROM tblStockIn
                GROUP BY productId
            ) AS si ON p.ProductID = si.productId";

                // Add search filter if search text is provided
                if (!string.IsNullOrEmpty(txtSearch.Text))
                {
                    query += @" WHERE b.Brand like '%" + txtSearch.Text + @"%' 
                OR g.Generic like '%" + txtSearch.Text + @"%' 
                OR c.Classification like '%" + txtSearch.Text + @"%' 
                OR t.TypeName like '%" + txtSearch.Text + @"%'";
                }

                query += " ORDER BY p.ProductID";

                using (SqlCommand cm = new SqlCommand(query, cn))
                using (SqlDataReader dr = cm.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        i++;
                        DateTime fDate = Convert.ToDateTime(dr["ExpiringDate"]);
                        string formattedFDate = fDate.ToString("dd/MM/yyyy");

                        dataGridView2.Rows.Add(
                            i,
                            dr["ProductID"].ToString(),
                            dr["Barcode"].ToString(),
                            dr["Brand"].ToString(),
                            dr["Generic"].ToString(),
                            dr["Classification"].ToString(),
                            dr["TypeName"].ToString(),
                            dr["FormulationName"].ToString(),
                            dr["Qty"].ToString(),                              // Current stock
                            double.Parse(dr["CostPrice"].ToString()).ToString("#,##0.0"),
                            dr["StockInQty"].ToString(),                       // Total received
                            double.Parse(dr["SellingPrice"].ToString()).ToString("#,##0.0"),
                            double.Parse(dr["Profit"].ToString()).ToString("#,##0.0"),
                            formattedFDate
                        );
                    }
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
            frmProductReportView frm = new frmProductReportView();

            string search = txtSearch.Text.Trim(); // get search text

            string query = @"
    SELECT 
        p.ProductID,
        p.Barcode,
        b.Brand,
        g.Generic,
        c.Classification,
        t.TypeName,
        f.FormulationName,
        p.Qty,  -- Current stock
        ISNULL(si.TotalStockIn, 0) AS StockInQty,  -- Total received stock
        p.CostPrice,
        p.SellingPrice,
        p.Profit,
        CAST(p.ExpiringDate AS date) AS ExpiringDate
    FROM tblProducts AS p
    INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
    INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
    INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
    INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
    INNER JOIN tblType AS t ON p.TypeId = t.TypeID
    LEFT JOIN (
        SELECT productId, SUM(StockInQty) AS TotalStockIn
        FROM tblStockIn
        GROUP BY productId
    ) AS si ON p.ProductID = si.productId
    WHERE 1=1";


//            string query = @"
//        SELECT 
//            p.ProductID,
//            p.Barcode,
//            b.Brand,
//            g.Generic,
//            c.Classification,
//            t.TypeName,
//            f.FormulationName,
//            p.Qty,  -- Current stock
//            ISNULL(si.TotalStockIn, 0) AS StockInQty,  -- Total received stock
//            p.CostPrice,
//            p.SellingPrice,
//            p.Profit,
//            p.ExpiringDate
//        FROM tblProducts AS p
//        INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
//        INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
//        INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
//        INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
//        INNER JOIN tblType AS t ON p.TypeId = t.TypeID
//        LEFT JOIN (
//            SELECT productId, SUM(StockInQty) AS TotalStockIn
//            FROM tblStockIn
//            GROUP BY productId
//        ) AS si ON p.ProductID = si.productId
//        WHERE 1=1";  // base query

            // ✅ Apply filter if search text is provided
            if (!string.IsNullOrEmpty(search))
            {
                query += " AND (g.Generic LIKE @search OR c.Classification LIKE @search OR t.TypeName LIKE @search)";
            }

            query += " ORDER BY p.ProductID";

            frm.LoadProductReport(query, search);
            frm.Show();
            
        }
    }
}
