﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmLogInForm : Form
    {
         SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;  
        
        public string _pass,  _username="";
        public int _userId;
        public bool _isactive = false;
        public frmLogInForm()
        {
            InitializeComponent();
             cn = new SqlConnection(dbcon.MyConnection());
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            string _role = "", _name = "";
            try
            {
                bool found = false;
                cn.Open();
                cm = new SqlCommand("select * from tblUser where UserName=@UserName and Password=@Password", cn);
                cm.Parameters.AddWithValue("@UserName", txt_username.Text);
                cm.Parameters.AddWithValue("@Password", txt_password.Text);
                dr = cm.ExecuteReader();
                //dr.Read();
                //if (dr.HasRows)
                while(dr.Read())
                {
                    found = true;
                    _userId = Convert.ToInt32(dr["UserId"]);   // add this
                    _username = dr["username"].ToString();
                    _role = dr["role"].ToString();
                    _name = dr["name"].ToString();
                    _pass = dr["password"].ToString();                   
                }
                //else
                //{
                //    found = false;
                //    _username = "";
                //    _role = "";
                //    _name = "";
                //    _pass = "";
                //}
                dr.Close();
                cn.Close();
                if (found == true)
                {

                    if (_role == "Cashier")
                    {
                        int i;

                        for (i = 0; i <= 5000; i++)
                        {
                            progressBar1.Increment(1);
                        }
                        MessageBox.Show(" Welcome" + _name + "!", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txt_username.Clear();
                        txt_password.Clear();
                        this.Hide();
                       frmSales fm = new frmSales();
                       fm.lblUser.Tag = _userId; 
                       fm.lblUser.Text = _username;                       
                       fm.lblName.Text = _name + "|" + _role;
                        fm.ShowDialog();
                    }
                    if (_role == "Admin")
                    {
                        int i;

                        for (i = 0; i <= 5000; i++)
                        {
                            progressBar1.Increment(1);
                        }
                        MessageBox.Show(" Welcome" + _name + "!", "ACCESS GRANTED", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        txt_username.Clear();
                        txt_password.Clear();
                        this.Hide();
                        Form1 fm = new Form1();
                        fm.lblName.Text = _name;
                        fm.lblUser.Text = _username;
                        fm.lblRole.Text = _role;
                        fm._pass = _pass;
                        fm._user = _username;                       
                        fm.LoadDashboard();
                        fm.ShowDialog();
                    }
                }
                else
                {
                    MessageBox.Show("Invalid username or password!", "ACCESS DENIED", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btn_exit_Click(object sender, EventArgs e)
        {
             if (MessageBox.Show("Please confirm if you want to exit the application?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        }
    }

