﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmVoid : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
     //   frmCancelDetails f;
        SqlDataReader dr;
        frmCancelDetails f;
        public frmVoid(frmCancelDetails flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            f = flist;
        }

        private void btnVoid_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if f and its controls are initialized
                if (f == null || f.txtInvoiceNo == null || f.txtID == null || f.txtCancelQty == null)
                {
                    MessageBox.Show("Required form controls are not initialized!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtUsername.Text))
                {
                    MessageBox.Show("Please enter both username and password!", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string user = null;
                using (cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();
                    using (cm = new SqlCommand("SELECT Username FROM tblUser WHERE Username = @Username AND Password = @Password", cn))
                    {
                        cm.Parameters.AddWithValue("@Username", txtUsername.Text.Trim());
                        cm.Parameters.AddWithValue("@Password", txtPassword.Text.Trim());

                        object result = cm.ExecuteScalar();

                        if (result != null)
                        {
                            user = result.ToString();
                        }
                    }
                }

                if (user != null)
                {
                    // User authenticated successfully
                    double price = double.Parse(f.txtPrice.Text);
                    int cancelQty = int.Parse(f.txtCancelQty.Text);
                    double amountToDeduct = price * cancelQty;

                    if (f.cboAction.Text == "Yes")
                    {
                        // YES: Return stock to tblProducts
                        UpdateDate("update tblProducts set Qty = Qty + @qty where ProductID = @productId",
                            new SqlParameter("@qty", cancelQty),
                            new SqlParameter("@productId", int.Parse(f.txtID.Text)));

                        // Don't save to tblCancel when Yes is selected
                    }
                    else
                    {
                        // NO: Save to tblCancel instead of returning to inventory
                        savedCancelOrder(user);
                    }

                    // Always reduce the sales quantity regardless of Yes/No
                    UpdateDate("update tblSales set Qty = Qty - @qty, LineTotal = LineTotal - @amount where ProductID = @productId and InvoiceNo = @invoiceNo",
                        new SqlParameter("@qty", cancelQty),
                        new SqlParameter("@amount", amountToDeduct),
                        new SqlParameter("@productId", int.Parse(f.txtID.Text)),
                        new SqlParameter("@invoiceNo", f.txtInvoiceNo.Text));

                    // Also update the total amount in sales detail
                    UpdateDate("update tblSalesDetail set Total = Total - @amount where InvoiceNo = @invoiceNo",
                        new SqlParameter("@amount", amountToDeduct),
                        new SqlParameter("@invoiceNo", f.txtInvoiceNo.Text));

                    // DELETE the sales record if quantity becomes zero
                    UpdateDate("DELETE FROM tblSales WHERE ProductID = @productId AND InvoiceNo = @invoiceNo AND Qty <= 0",
                        new SqlParameter("@productId", int.Parse(f.txtID.Text)),
                        new SqlParameter("@invoiceNo", f.txtInvoiceNo.Text));

                    string message = "Order transaction successfully cancelled! ";
                    if (f.cboAction.Text == "Yes")
                    {
                        message += "Inventory returned to products.";
                    }
                    else
                    {
                        message += "Recorded in cancellation log.";
                    }

                    MessageBox.Show(message, "Cancelled Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Dispose();
                    f.RefresList();
                }
                else
                {
                    MessageBox.Show("Invalid username or password! Please check your credentials.", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


            //try
            //{
            //    // Check if f and its controls are initialized
            //    if (f == null || f.txtInvoiceNo == null || f.txtID == null || f.txtCancelQty == null)
            //    {
            //        MessageBox.Show("Required form controls are not initialized!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        return;
            //    }

            //    if (string.IsNullOrEmpty(txtPassword.Text))
            //    {
            //        MessageBox.Show("Please enter password!", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //        return;
            //    }

            //    string user;
            //    using (cn = new SqlConnection(dbcon.MyConnection()))
            //    {
            //        cn.Open();
            //        using (cm = new SqlCommand("select * from tblUser where Username=@Username and Password=@Password", cn))
            //        {
            //            cm.Parameters.AddWithValue("@Username", txtUsername.Text);
            //            cm.Parameters.AddWithValue("@Password", txtPassword.Text);

            //            using (dr = cm.ExecuteReader())
            //            {
            //                if (dr.Read())
            //                {
            //                    user = dr["Username"].ToString();

            //                    // Always save to tblCancel first
            //                    savedCancelOrder(user);

            //                    if (f.cboAction.Text == "Yes")
            //                    {
            //                        // Return stock to tblProducts
            //                        UpdateDate("update tblProducts set Qty = Qty + @qty where ProductID = @productId",
            //                            new SqlParameter("@qty", int.Parse(f.txtCancelQty.Text)),
            //                            new SqlParameter("@productId", int.Parse(f.txtID.Text)));
            //                    }

            //                    // Always reduce the sales quantity regardless of Yes/No
            //                    UpdateDate("update tblSales set Qty = Qty - @qty where ProductID = @productId and InvoiceNo = @invoiceNo",
            //                        new SqlParameter("@qty", int.Parse(f.txtCancelQty.Text)),
            //                        new SqlParameter("@productId", int.Parse(f.txtID.Text)),
            //                        new SqlParameter("@invoiceNo", f.txtInvoiceNo.Text));

            //                    // DELETE the sales record if quantity becomes zero
            //                    UpdateDate("DELETE FROM tblSales WHERE ProductID = @productId AND InvoiceNo = @invoiceNo AND Qty <= 0",
            //                        new SqlParameter("@productId", int.Parse(f.txtID.Text)),
            //                        new SqlParameter("@invoiceNo", f.txtInvoiceNo.Text));

            //                    string message = "Order transaction successfully cancelled! ";
            //                    if (f.cboAction.Text == "Yes")
            //                    {
            //                        message += "Inventory returned to products.";
            //                    }
            //                    else
            //                    {
            //                        message += "Recorded in cancellation log.";
            //                    }

            //                    MessageBox.Show(message, "Cancelled Order", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //                    this.Dispose();
            //                    f.RefresList();
            //                }
            //                else
            //                {
            //                    MessageBox.Show("Invalid username or password!", "Authentication Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //                }
            //            }
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
        }

        public void savedCancelOrder(string user)
        {
            // Validate all required fields
            if (string.IsNullOrEmpty(f.txtInvoiceNo.Text) ||
                string.IsNullOrEmpty(f.txtID.Text) || // Use txtID since it contains ProductID
                string.IsNullOrEmpty(f.txtCancelQty.Text))
            {
                throw new Exception("Required fields are missing for cancellation");
            }

            // Get numeric BrandID from brand name
            int brandId = GetBrandIdByName(f.txtBrand.Text);
            if (brandId == 0)
            {
                throw new Exception("Brand not found: " + f.txtBrand.Text);
            }

            // Get numeric IDs for other foreign keys if needed
            int genericId = GetGenericIdByName(f.txtGeneric.Text);
            int classificationId = GetClassificationIdByName(f.txtClassification.Text);
            int typeId = GetTypeIdByName(f.txtType.Text);
            int formulationId = GetFormulationIdByName(f.txtFormation.Text);

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand(@"
            INSERT INTO tblCancel 
            (InvoiceNo, ProductId, BrandId, GenericId, ClassificationId, TypeId, FormulationId, 
             Price, qty, total, sdate, voidby, cancelledby, reason, action)
            VALUES
            (@InvoiceNo, @ProductId, @BrandId, @GenericId, @ClassificationId, @TypeId, @FormulationId, 
             @Price, @qty, @total, @sdate, @voidby, @cancelledby, @reason, @action)", connection))
                {
                    command.Parameters.AddWithValue("@InvoiceNo", f.txtInvoiceNo.Text);
                    command.Parameters.AddWithValue("@ProductId", int.Parse(f.txtID.Text)); // Use txtID for ProductID
                    command.Parameters.AddWithValue("@BrandId", brandId);
                    command.Parameters.AddWithValue("@GenericId", genericId);
                    command.Parameters.AddWithValue("@ClassificationId", classificationId);
                    command.Parameters.AddWithValue("@TypeId", typeId);
                    command.Parameters.AddWithValue("@FormulationId", formulationId);
                    command.Parameters.AddWithValue("@Price", double.Parse(f.txtPrice.Text));
                    command.Parameters.AddWithValue("@qty", int.Parse(f.txtCancelQty.Text));
                    command.Parameters.AddWithValue("@total", double.Parse(f.txtTotal.Text));
                    command.Parameters.AddWithValue("@sdate", DateTime.Now);
                    command.Parameters.AddWithValue("@voidby", user);
                    command.Parameters.AddWithValue("@cancelledby", f.txtCancel.Text ?? "");
                    command.Parameters.AddWithValue("@reason", f.txtReason.Text ?? "");
                    command.Parameters.AddWithValue("@action", f.cboAction.Text ?? "");

                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateDate(string sql, params SqlParameter[] parameters)
        {
            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand(sql, connection))
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.Add(param);
                    }
                    command.ExecuteNonQuery();
                }
            }
        }


        private int GetBrandIdByName(string brandName)
        {
            if (string.IsNullOrEmpty(brandName)) return 0;

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT BrandId FROM tblBrand WHERE Brand = @name", connection))
                {
                    command.Parameters.AddWithValue("@name", brandName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        // Helper method to get GenericID from generic name
        private int GetGenericIdByName(string genericName)
        {
            if (string.IsNullOrEmpty(genericName)) return 0;

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT GenericId FROM tblGeneric WHERE Generic = @name", connection))
                {
                    command.Parameters.AddWithValue("@name", genericName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        // Helper method to get ClassificationID from classification name
        private int GetClassificationIdByName(string classificationName)
        {
            if (string.IsNullOrEmpty(classificationName)) return 0;

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT ClassificationId FROM tblClassification WHERE Classification = @name", connection))
                {
                    command.Parameters.AddWithValue("@name", classificationName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        // Helper method to get TypeID from type name
        private int GetTypeIdByName(string typeName)
        {
            if (string.IsNullOrEmpty(typeName)) return 0;

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT TypeId FROM tblType WHERE TypeName = @name", connection))
                {
                    command.Parameters.AddWithValue("@name", typeName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        // Helper method to get FormulationID from formulation name
        private int GetFormulationIdByName(string formulationName)
        {
            if (string.IsNullOrEmpty(formulationName)) return 0;

            using (var connection = new SqlConnection(dbcon.MyConnection()))
            {
                connection.Open();
                using (var command = new SqlCommand("SELECT FormulationId FROM tblFormulation WHERE FormulationName = @name", connection))
                {
                    command.Parameters.AddWithValue("@name", formulationName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : 0;
                }
            }
        }

        
       

        //BackToInventory
        //public void UpdateDate(string sql)
        //{
        //    cn.Open();
        //    cm = new SqlCommand(sql, cn);
        //    cm.ExecuteNonQuery();
        //    cn.Close();
        //}

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
    }
}
