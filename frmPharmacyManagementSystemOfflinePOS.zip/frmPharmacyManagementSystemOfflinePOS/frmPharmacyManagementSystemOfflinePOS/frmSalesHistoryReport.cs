﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmSalesHistoryReport : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
       // SqlDataReader dr;
        frmSalesHistory fm;
        public frmSalesHistoryReport(frmSalesHistory flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            fm = flist;

        }

        private void frmSalesHistoryReport_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        public void LoadSalesHistoryReport()
        {
            ReportDataSource rptReportDataSource;

            try
            {
                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptSalesHistory.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();

                DataSet ds = new DataSet();

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    string sql = @"
                SELECT 
                    s.SalesID, 
                    s.InvoiceNo,
                    s.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    s.Price, 
                    s.Qty,
                    s.Discount,
                    s.LineTotal,                  
                    sd.SalesDate,
                    sd.ServedBy,
                    s.PaymentMode
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0";

                    // ✅ Same date filter logic
                    if (fm.dt1.Value.Date == fm.dt2.Value.Date)
                    {
                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
                    }
                    else
                    {
                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
                    }

                    // ✅ Filter by cashier
                    if (fm.cboCashier.Text != "All Cashier")
                    {
                        sql += " AND sd.ServedBy = @cashier";
                    }

                    SqlCommand cmd = new SqlCommand(sql, cn);
                    cmd.Parameters.Add("@date1", SqlDbType.Date).Value = fm.dt1.Value.Date;

                    if (fm.dt1.Value.Date != fm.dt2.Value.Date)
                    {
                        cmd.Parameters.Add("@date2", SqlDbType.DateTime).Value = fm.dt2.Value.Date.AddDays(1).AddSeconds(-1);
                    }

                    if (fm.cboCashier.Text != "All Cashier")
                    {
                        int cashierId;
                        if (int.TryParse(fm.cboCashier.SelectedValue.ToString(), out cashierId))
                        {
                            cmd.Parameters.Add("@cashier", SqlDbType.Int).Value = cashierId;
                        }
                        else
                        {
                            MessageBox.Show("Invalid cashier selection!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    SqlDataAdapter da = new SqlDataAdapter(cmd);

                    // ✅ Ensure "dtReceipt" matches your DataTable name in the RDLC
                    da.Fill(ds, "dtReceipt");
                }

                // Report Parameters
                ReportParameter pDate = new ReportParameter("pDate","Date From: " + fm.dt1.Value.ToString("dd-MM-yyyy") + " To: " + fm.dt2.Value.ToString("dd-MM-yyyy")
                );
                ReportParameter pCashier = new ReportParameter("pCashier", "Cashier: " + fm.cboCashier.Text);
                ReportParameter pHeader = new ReportParameter("pHeader", "SALES REPORT");

                reportViewer1.LocalReport.SetParameters(pDate);
                reportViewer1.LocalReport.SetParameters(pCashier);
                reportViewer1.LocalReport.SetParameters(pHeader);

              
                rptReportDataSource = new ReportDataSource("DataSet", ds.Tables["dtReceipt"]);
                reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);

                // Report viewer settings
                reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                reportViewer1.ZoomMode = ZoomMode.Percent;
                reportViewer1.ZoomPercent = 100;


                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }





    }
}
