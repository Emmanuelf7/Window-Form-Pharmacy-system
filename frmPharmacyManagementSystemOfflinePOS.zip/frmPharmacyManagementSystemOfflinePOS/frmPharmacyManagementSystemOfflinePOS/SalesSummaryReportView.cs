﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class SalesSummaryReportView : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        // SqlDataReader dr;
        frmSalesRecordList f;
        public SalesSummaryReportView(frmSalesRecordList fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            f = fm;
        }

        private void SalesSummaryReportView_Load(object sender, EventArgs e)
        {

            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }

        public void LoadSalesSummaryReport()
        {
            ReportDataSource rptReportDataSource;

            try
            {
                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptSalesSummary.rdlc";
                this.reportViewer1.LocalReport.DataSources.Clear();

                DataSet ds = new DataSet();
                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    string sql = @"
                SELECT 
                    s.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    SUM(s.Qty) AS Qty,
                    SUM(s.LineTotal) AS LineTotal,
                    SUM(sd.Vat) AS Vat,
                    p.CostPrice,
                    p.SellingPrice,
                    p.Profit AS UnitProfit
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                INNER JOIN tblProducts p ON s.ProductID = p.ProductID
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0
            ";

                    // ✅ Append date filter before GROUP BY
                    if (f.dt3.Value.Date == f.dt4.Value.Date)
                    {
                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
                    }
                    else
                    {
                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
                    }

                    sql += @"
                GROUP BY 
                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName, 
                    p.CostPrice, p.SellingPrice, p.Profit
                ORDER BY SUM(s.Qty) DESC"; // highest selling first

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@date1", f.dt3.Value.Date);

                        if (f.dt3.Value.Date != f.dt4.Value.Date)
                        {
                            cmd.Parameters.AddWithValue("@date2", f.dt4.Value.Date.AddDays(1).AddSeconds(-1));
                        }

                        SqlDataAdapter da = new SqlDataAdapter(cmd);

                        // ✅ Ensure "dtReceipt" matches your DataTable name in the RDLC
                        da.Fill(ds, "dtReceipt");
                    }

                    // Report Parameters
                    ReportParameter pDate = new ReportParameter(
                        "pDate",
                        "Date From: " + f.dt3.Value.ToString("dd-MM-yyyy") + " To: " + f.dt4.Value.ToString("dd-MM-yyyy")
                    );

                    reportViewer1.LocalReport.SetParameters(pDate);

                    rptReportDataSource = new ReportDataSource("DataSet", ds.Tables["dtReceipt"]);
                    reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);

                    // Report viewer settings
                    reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
                    reportViewer1.ZoomMode = ZoomMode.Percent;
                    reportViewer1.ZoomPercent = 100;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

//        public void LoadSalesSummaryReport()
//        {
//            ReportDataSource rptReportDataSource;

//            try
//            {
//                this.reportViewer1.LocalReport.ReportPath = Application.StartupPath + @"\Reports\rptSalesSummary.rdlc";
//                this.reportViewer1.LocalReport.DataSources.Clear();

//                DataSet ds = new DataSet();
//                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
//                {
//                    connection.Open();

//                    string sql = @"
//               SELECT 
//                    s.ProductID,
//                    b.Brand,
//                    g.Generic,
//                    c.Classification,
//                    t.TypeName,
//                    f.FormulationName,
//                    SUM(s.Qty) AS Qty,
//                    SUM(s.LineTotal) AS Total,
//                    SUM(sd.Vat) AS Vat,
//                    p.CostPrice,
//                    p.SellingPrice,
//                    p.Profit AS UnitProfit
//                FROM tblSales s
//                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
//                INNER JOIN tblProducts p ON s.ProductID = p.ProductID
//                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
//                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
//                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
//                LEFT JOIN tblType t ON s.TypeId = t.TypeID
//                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
//                WHERE s.Qty > 0
//                -- (date filter here)
//                GROUP BY 
//                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName, 
//                    p.CostPrice, p.SellingPrice, p.Profit
//                ORDER BY SUM(s.Qty) DESC
//            ";

//                    // Filter by date
//                    if (f.dt3.Value.Date == f.dt4.Value.Date)
//                    {
//                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
//                    }
//                    else
//                    {
//                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
//                    }

//                    sql += @"
//                GROUP BY 
//                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName, 
//                    p.CostPrice, p.SellingPrice, p.Profit
//                ORDER BY SUM(s.Qty) DESC"; // highest selling first

//                    using (SqlCommand cmd = new SqlCommand(sql, connection))
//                    {
//                        cmd.Parameters.AddWithValue("@date1", f.dt3.Value.Date);

//                        if (f.dt3.Value.Date != f.dt4.Value.Date)
//                        {
//                            cmd.Parameters.AddWithValue("@date2", f.dt4.Value.Date.AddDays(1).AddSeconds(-1));
//                        }

//                        SqlDataAdapter da = new SqlDataAdapter(cmd);

//                        // ✅ Ensure "dtReceipt" matches your DataTable name in the RDLC
//                        da.Fill(ds, "dtReceipt");
//                    }

//                    // Report Parameters
//                    ReportParameter pDate = new ReportParameter("pDate", "Date From: " + f.dt3.Value.ToString("dd-MM-yyyy") + " To: " + f.dt4.Value.ToString("dd-MM-yyyy")
//                    );

                 
//                    reportViewer1.LocalReport.SetParameters(pDate);

//                    rptReportDataSource = new ReportDataSource("DataSet", ds.Tables["dtReceipt"]);
//                    reportViewer1.LocalReport.DataSources.Add(rptReportDataSource);

//                    // Report viewer settings
//                    reportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout);
//                    reportViewer1.ZoomMode = ZoomMode.Percent;
//                    reportViewer1.ZoomPercent = 100;


//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error: " + ex.Message, "Report Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
//        }
    }
}
