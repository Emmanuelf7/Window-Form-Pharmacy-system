﻿using frmPharmacyManagementSystemOfflinePOS.ApplicationActivate;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tulpep.NotificationWindow;
namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class Form1 : Form
    {
     //   private DateTime trialExpirationDate;
      //  private string activationKey = "1234-5678-ABCD-EFGH"; // Example activation key
   
        //private DateTime expirationDate;
        private const string trialFile = "trial_info.txt";

        // Delegate to update the trial status
        public delegate void UpdateTrialStatusDelegate(string status);
        public UpdateTrialStatusDelegate UpdateTrialStatus;



        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public string _pass, _user;
        public Form1()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());          
            LoadDashboard();
            NotifyExpiringProduct();
            CheckTrial();
            UpdateTrialStatus = new UpdateTrialStatusDelegate(UpdateStatus); // Assign the delegate
            // Add click event handler for lblStatus
            lblStatus.Click += labelStatus_Click;
        }
        // Method to update the status of the trial
        private void UpdateStatus(string status)
        {
            lblStatus.Text = status;
        }

        // Checks the trial expiration date and whether the app is activated
        // Checks the trial expiration date and whether the app is activated
        private void CheckTrial()
        {
        
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, trialFile);

            // If the trial file doesn't exist or an error occurs, set a new trial period.
            if (!File.Exists(filePath))
            {
                SetTrialPeriod(30);  // Set a new trial period if file doesn't exist
                return;
            }

            try
            {
                string[] data = File.ReadAllLines(filePath);

                // If no data in the file, set a new trial period.
                if (data.Length == 0)
                {
                    SetTrialPeriod(30);
                    return;
                }

                DateTime expirationDate;

                // Try to parse the expiration date from the file.
                if (DateTime.TryParse(data[0], out expirationDate))
                {
                    // If the expiration date is the max value, it's permanently activated
                    if (expirationDate == DateTime.MaxValue)
                    {
                        lblStatus.Text = "Application Activated Permanently."; // Show permanent activation status
                        EnablePanel2();  // Enable only panel2 (main panel)
                        EnableSidebar(); // Enable sidebar if permanently activated
                    }
                    else if (expirationDate < DateTime.Now)
                    {
                        lblStatus.Text = "Your trial period has expired."; // Show trial expired message
                        DisableSidebar();  // Disable only the sidebar panel
                        DisablePanel2();   // Optionally disable panel2
                    }
                    else
                    {
                        lblStatus.Text = "Active: " + expirationDate.ToShortDateString(); // Show active trial date
                        EnablePanel2();  // Enable panel2
                        EnableSidebar(); // Enable sidebar if the trial is still active
                    }
                }
                else
                {
                    lblStatus.Text = "Invalid trial data. Setting a new trial period."; // If the data is invalid
                    SetTrialPeriod(30);
                    EnablePanel2();  // Enable panel2
                    EnableSidebar(); // Enable sidebar if the trial data is invalid
                }
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Error reading trial information: " + ex.Message; // Handle any errors
                SetTrialPeriod(30);
                EnablePanel2();  // Enable panel2
                EnableSidebar(); // Enable sidebar if there's an error
            }
        }

        // Method to disable the sidebar panel
        private void DisableSidebar()
        {
            panel2.Enabled = false;  // Disable the sidebar panel
        }

        // Method to enable the sidebar panel
        private void EnableSidebar()
        {
            panel2.Enabled = true;  // Enable the sidebar panel
        }

        // Method to enable panel2
        private void EnablePanel2()
        {
            panel2.Enabled = true;  // Enable panel2 (assuming it's the main content panel)
        }

        // Method to disable panel2
        private void DisablePanel2()
        {
            panel2.Enabled = false;  // Disable panel2 if required (e.g., when the trial is expired)
        }

        // Method to enable all controls (if needed for a full re-enable)
        private void EnableAllControls()
        {
            foreach (Control control in this.Controls)
            {
                control.Enabled = true;  // Enable all controls
            }
        }
       
// Recursive method to disable all controls except lblStatus
private void DisableControlsRecursively(Control.ControlCollection controls)
{
    foreach (Control control in controls)
    {
        if (control != lblStatus)  // Skip the lblStatus control
        {
            control.Enabled = false;  // Disable the control
        }

        // If the control is a container (like a Panel, GroupBox, etc.), recurse into it
        if (control.HasChildren)
        {
            DisableControlsRecursively(control.Controls);
        }
    }
}



        private void SetTrialPeriod(int days)
        {
            DateTime trialExpirationDate = DateTime.Now.AddDays(days);
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, trialFile);
            File.WriteAllLines(filePath, new[] { trialExpirationDate.ToString() });
            lblStatus.Text = "Trial Active until: " + trialExpirationDate.ToShortDateString();
        }

       

        // When the lblStatus is clicked, show the ActivateForm
        private void lblStatus_Click(object sender, EventArgs e)
        {
            // Show the activation form and pass the delegate
            var activateForm = new ActivateApplication(UpdateTrialStatus);
            activateForm.ShowDialog();
        }

        private void DisableForm()
        {
            // Disable the entire form, making it non-interactive
            this.Enabled = false;

            // Optionally, you can also change the form background color to indicate the disabled state
            this.BackColor = Color.Gray;

            // If you want to disable individual controls instead of the whole form, loop through the controls and disable them
            foreach (Control control in this.Controls)
            {
                control.Enabled = false;
            }
        }



        public void LoadDashboard()
        {

            lblDailySales frm = new lblDailySales();
            frm.TopLevel = false;
            frm.FormBorderStyle = FormBorderStyle.None;   // remove borders
            frm.Dock = DockStyle.Fill;                    // fill the panel
            panel4.Controls.Add(frm);
            frm.BringToFront();

            // update labels
            frm.lblDailySale.Text = dbcon.DailySales().ToString("GHC#,##0.00");
            frm.lblProductLine.Text = dbcon.ProductLine().ToString("#,##0");
            frm.lblStockOnHand.Text = dbcon.StockOnHand().ToString("#,##0");
            frm.lblCritical.Text = dbcon.CriticalStock().ToString("0");
            frm.lblDisplayExpiringProduct.Text = dbcon.ExpiringProduct().ToString("0");
            NotifyExpiringProduct();
          
            frm.Show();
        }


        //public void LoadDashboard()
        //{
        //    frmDashBoard frm = new frmDashBoard();
        //    frm.TopLevel = false;
        //    panel4.Controls.Add(frm);
        //    frm.BringToFront();
        //    frm.lblDailySales.Text = dbcon.DailySales().ToString("GHC#,##0.00");
        //    //frm.lblProductLine.Text = dbcon.ProductLine().ToString("#,##0");
        //    //frm.lblStockOnHand.Text = dbcon.StockOnHand().ToString("#,##0");
        //    //frm.lblCritical.Text = dbcon.CriticalItems().ToString("#,##0");
        //    frm.lblDisplayExpiringProduct.Text = dbcon.ExpiringProduct().ToString("0");
        //    NotifyExpiringProduct();
        //    frm.Show();
        //}




        public void NotifyExpiringProduct()
        {
            string expiring = "";
            cn.Open();
            cm = new SqlCommand("select count(*) as ExpiringProductCount from tblProducts where ExpiringDate <= DATEADD(day,30, GETDATE())", cn);
            string count = cm.ExecuteScalar().ToString();
            cn.Close();

            int i = 0;
            cn.Open();
            // cm = new SqlCommand("select * from tblProduct", cn);
            cm = new SqlCommand("select * from tblProducts as p inner join tblBrand as b on p.BrandId=b.BrandID inner join tblClassification as c on p.ClassificationId=c.ClassificationId inner join tblFormulation as f on p.FormulationId=f.FormulationID inner join tblGeneric as g on p.GenericId=g.GenericID inner join tblType as t on p.TypeId=t.TypeID where ExpiringDate <= DATEADD(day,30, GETDATE())", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                expiring += i + "." + dr["Generic"].ToString() + Environment.NewLine;

            }
            dr.Close();
            cn.Close();

            PopupNotifier popup = new PopupNotifier();
            popup.Image = Properties.Resources.close_button_icon;
            popup.TitleText = count + "Product(s) Will Soon Expire";
            popup.ContentText = expiring;
            popup.Popup();
        }
        private void btn_Category_Click(object sender, EventArgs e)
        {
            //frm_ClassificationList frm = new frm_ClassificationList();
            frmMaintenance frm = new frmMaintenance();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.txtVat.Text =dbcon.GetVat().ToString();
            frm.Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("LOGOUT THE APPLICATION ?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                frmLogInForm frm = new frmLogInForm();
                frm.ShowDialog();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmProductList frm = new frmProductList();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            frmSalesRecordList frm = new frmSalesRecordList();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.LoadTopSellingRecord();
         //  frm.LoadSalesRecord();
            frm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            frm_StockIn frm = new frm_StockIn();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.Show();
        }

        private void labelStatus_Click(object sender, EventArgs e)
        {
            // Show the activation form and pass the delegate
            var activateForm = new ActivateApplication(UpdateTrialStatus);
            activateForm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            frmCriticalStock frm = new frmCriticalStock();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.LoadCriticalStock();
            frm.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmSalesHistory frm = new frmSalesHistory();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            frmCancelTransaction frm = new frmCancelTransaction();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.LoadCancelledOrders();
            frm.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            frmExpensisList frm = new frmExpensisList();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.getAllExpensisRecord();
            frm.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            frmCreateNewUser frm = new frmCreateNewUser();

            frm.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            frmNewUserList frm = new frmNewUserList();
            frm.TopLevel = false;
            panel4.Controls.Add(frm);
            frm.BringToFront();
            frm.LoadUsers();
            frm.Show();
        }

        private void btnDashBoard_Click(object sender, EventArgs e)
        {
           // frmDashBoard frm = new frmDashBoard(this);
            LoadDashboard();
        }
    }
}
