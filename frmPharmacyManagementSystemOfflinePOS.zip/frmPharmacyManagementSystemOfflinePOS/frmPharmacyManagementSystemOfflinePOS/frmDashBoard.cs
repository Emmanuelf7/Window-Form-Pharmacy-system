﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class lblDailySales : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        public lblDailySales()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadChart();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frmDashBoard_Load(object sender, EventArgs e)
        {
            panel1.Left = (this.Width - panel1.Width) / 2;
        }

        public void LoadChart()
        {
            try
            {
                cn.Open();

                // Current year
                int year = DateTime.Now.Year;

                string sql = @"
            SELECT 
                MONTH(sd.SalesDate) AS MonthNumber,
                ISNULL(SUM(s.LineTotal),0) AS Tot_TotalPriceQty
            FROM tblSales s
            INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
            LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
            LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
            LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
            LEFT JOIN tblType t ON s.TypeId = t.TypeID
            LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
            WHERE s.Qty > 0
              AND YEAR(sd.SalesDate) = @year
            GROUP BY MONTH(sd.SalesDate)
            ORDER BY MONTH(sd.SalesDate)";

                SqlCommand cmd = new SqlCommand(sql, cn);
                cmd.Parameters.AddWithValue("@year", year);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dtSales = new DataTable();
                da.Fill(dtSales);

                // Add month names column
                dtSales.Columns.Add("MonthName", typeof(string));
                foreach (DataRow row in dtSales.Rows)
                {
                    int monthNum = Convert.ToInt32(row["MonthNumber"]);
                    row["MonthName"] = new DateTime(1, monthNum, 1).ToString("MMMM");
                }

                // Bind to chart
                chart1.Series.Clear();
                Series series1 = new Series("Monthly Sales");
                chart1.Series.Add(series1);
                series1.ChartType = SeriesChartType.Column;
                series1.XValueMember = "MonthName";
                series1.YValueMembers = "Tot_TotalPriceQty";
                series1.IsValueShownAsLabel = true;

                chart1.DataSource = dtSales;
                chart1.DataBind();
                chart1.Update();
                chart1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chart: " + ex.Message);
            }
            finally
            {
                cn.Close();
            }
        }

    }
}
