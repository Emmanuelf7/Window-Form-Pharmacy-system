﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_Brand : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        frmMaintenance fm;
        SqlDataReader dr;
        public frm_Brand(frmMaintenance flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm = flist;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
            txt_Brand.Clear();
            txt_Brand.Focus();
            return;
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
           
            try
            {
                bool found = false;
                cn.Open();
                cm = new SqlCommand("select * from tblBrand where Brand like @Brand", cn);
                cm.Parameters.AddWithValue("@Brand", "%" + txt_Brand.Text + "%");
                dr = cm.ExecuteReader(); // Initialize the SqlDataReader here
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        found = true;
                    }
                }
                dr.Close();
                cn.Close();
                if (found == false)
                {
                    if (MessageBox.Show("Please confirm if you want to save this brand?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("INSERT INTO tblBrand(Brand) VALUES(@Brand)", cn);
                        cm.Parameters.AddWithValue("@Brand", txt_Brand.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        fm.LoadBrand();
                        Clear();
                        MessageBox.Show("Brand name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }        
                    }
                    else
                    {
                        MessageBox.Show("Error: Duplicate entry!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                   
               
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
             try
            {
                if (MessageBox.Show("Please confirm if you want to update this brand?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblBrand SET Brand=@Brand where BrandID like '" + lblBrandId.Text + "'", cn);
                    cm.Parameters.AddWithValue("@Brand", txt_Brand.Text);                
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Brand has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    fm.LoadBrand();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        }

        }
    

