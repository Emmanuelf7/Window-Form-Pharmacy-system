﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmUpDaeUserDetail : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        frmNewUserList f;
        public frmUpDaeUserDetail(frmNewUserList fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            f = fm;
        }

        private void btn_changePassword_Click(object sender, EventArgs e)
        {
            try
            {
                

                cn.Open();
                cm = new SqlCommand("update tblUser set Password=@Password,Name=@Name,UserName=@UserName,Role=@Role where UserId like'" + lblUser.Text + "'", cn);
                cm.Parameters.AddWithValue("@Name", txtName.Text);
                cm.Parameters.AddWithValue("@UserName", txtUsername.Text);
                cm.Parameters.AddWithValue("@Password", txtPassword.Text);
                cm.Parameters.AddWithValue("@Role", cbo_role.Text);
                cm.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Password has been successfully changed!", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
                f.LoadUsers();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
