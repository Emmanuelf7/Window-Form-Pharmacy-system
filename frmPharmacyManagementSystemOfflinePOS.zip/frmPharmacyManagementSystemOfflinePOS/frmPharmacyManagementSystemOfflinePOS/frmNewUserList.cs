﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmNewUserList : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public frmNewUserList()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadUsers();

        }

        public void LoadUsers()
        {
            try
            {
                int i = 0;
                dataGridView2.Rows.Clear();

                cn.Open();
                cm = new SqlCommand("select UserId, Name,UserName,Password,Role from tblUser", cn);
                dr = cm.ExecuteReader();
                while (dr.Read())
                {
                    i++;

                    dataGridView2.Rows.Add(i, dr["UserId"].ToString(), dr["Name"].ToString(), dr["UserName"].ToString(), dr["Password"].ToString(), dr["Role"].ToString());
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                dr.Close();
                cn.Close();
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit")
            {
                frmUpDaeUserDetail frm = new frmUpDaeUserDetail(this);
                // frm.btn_Update.Enabled = true;
                // frm.btn_Save.Enabled = false;
                frm.lblUser.Text = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
                frm.txtName.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
                frm.txtUsername.Text = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
                frm.txtPassword.Text = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();
                frm.cbo_role.Text = dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString();

                frm.Show();
                LoadUsers();

            }
            else if (ColName == "Delete")
            {
                if (MessageBox.Show("DELETE THIS RECORD? CLICK YES TO CONFIRM", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblUser where UserId like '" + dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("The Record has been successfully deleted.");
                    LoadUsers();
                }
            }
        }


    }
}
