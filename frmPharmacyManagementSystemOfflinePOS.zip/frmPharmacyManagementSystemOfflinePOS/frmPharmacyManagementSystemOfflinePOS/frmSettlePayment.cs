﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmSettlePayment : Form
    {
         SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        string stitle = "POS";
        frmSales fm;

        public frmSettlePayment(frmSales flist)
        {
            InitializeComponent();
             cn = new SqlConnection(dbcon.MyConnection());
             this.fm = flist;
        }

        private void txtTendered_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double sales = double.Parse(txtFinalTotal.Text);
                double cash = double.Parse(txtTendered.Text);
                double change = cash - sales;
                txtBalance.Text = change.ToString("#,##0.00");
            }
            catch (Exception)
            {
                txtBalance.Text = "0.00";

            }
        }

        // ADD THE METHOD HERE - near GetProductIdFromCart
        private string GetAvailableStockId(string productId, string quantity, SqlConnection connection, SqlTransaction transaction)
        {
            string stockId = "";
            try
            {
                // Get the first available stock entry that has sufficient quantity (FIFO)
                using (SqlCommand cm = new SqlCommand(@"
            SELECT TOP 1 StockId 
            FROM tblStockIn 
            WHERE ProductId = @ProductId AND StockInQty >= @Quantity
            ORDER BY Sdate ASC", connection, transaction))
                {
                    cm.Parameters.AddWithValue("@ProductId", int.Parse(productId));
                    cm.Parameters.AddWithValue("@Quantity", int.Parse(quantity));
                    object result = cm.ExecuteScalar();
                    if (result != null)
                        stockId = result.ToString();
                }

                // If no single stock entry has enough quantity, try to find the oldest entry
                if (string.IsNullOrEmpty(stockId))
                {
                    using (SqlCommand cm = new SqlCommand(@"
                SELECT TOP 1 StockId 
                FROM tblStockIn 
                WHERE ProductId = @ProductId AND StockInQty > 0
                ORDER BY Sdate ASC", connection, transaction))
                    {
                        cm.Parameters.AddWithValue("@ProductId", int.Parse(productId));
                        object result = cm.ExecuteScalar();
                        if (result != null)
                            stockId = result.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error getting stock ID: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return stockId;
        }
    
        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cmboPaymentMode.Text.Trim()))
                {
                    MessageBox.Show("Please Select Payment Mode!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    cmboPaymentMode.Focus();
                    return;
                }

                // Validate inputs
                if (string.IsNullOrEmpty(txtTendered.Text.Trim()) || string.IsNullOrEmpty(txtFinalTotal.Text))
                {
                    MessageBox.Show("Please enter payment details!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Use TryParse instead of Parse to avoid exceptions
                double tendered, finalTotal;
                if (!double.TryParse(txtTendered.Text, out tendered) ||
                    !double.TryParse(txtFinalTotal.Text, out finalTotal))
                {
                    MessageBox.Show("Please enter valid numbers for payment!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (tendered < finalTotal)
                {
                    MessageBox.Show("Insufficient amount. Please enter the correct amount!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();
                    SqlTransaction transaction = cn.BeginTransaction();

                    try
                    {
                        // Process each item in the cart
                        for (int i = 0; i < fm.dataGridView2.Rows.Count; i++)
                        {
                            if (fm.dataGridView2.Rows[i].IsNewRow) continue;

                            string cartId = fm.dataGridView2.Rows[i].Cells["dgvSrID"].Value == null ? "" : fm.dataGridView2.Rows[i].Cells["dgvSrID"].Value.ToString();
                            string productId = fm.GetProductIdFromCart(cartId);
                            string quantity = fm.dataGridView2.Rows[i].Cells["dgvQty"].Value == null ? "0" : fm.dataGridView2.Rows[i].Cells["dgvQty"].Value.ToString();

                            if (string.IsNullOrEmpty(productId) || string.IsNullOrEmpty(quantity) || string.IsNullOrEmpty(cartId))
                                continue;

                            // Get the FIRST available StockId for this product (FIFO approach)
                            string stockId = GetAvailableStockId(productId, quantity, cn, transaction);

                            if (string.IsNullOrEmpty(stockId))
                            {
                                throw new Exception("No available stock for product " + productId + ". Requested: " + quantity);
                            }

                            // Check stock availability before updating
                            using (SqlCommand checkCmd = new SqlCommand("SELECT StockInQty FROM tblStockIn WHERE StockId = @StockId", cn, transaction))
                            {
                                checkCmd.Parameters.AddWithValue("@StockId", int.Parse(stockId));
                                int availableStock = Convert.ToInt32(checkCmd.ExecuteScalar());

                                if (availableStock < int.Parse(quantity))
                                {
                                    throw new Exception("Insufficient stock for product " + productId + ". Available: " + availableStock + ", Requested: " + quantity);
                                }
                            }

                            // Update ONLY the specific stock entry
                            using (SqlCommand cm = new SqlCommand("UPDATE tblStockIn SET StockInQty = StockInQty - @Quantity WHERE StockId = @StockId", cn, transaction))
                            {
                                cm.Parameters.AddWithValue("@Quantity", int.Parse(quantity));
                                cm.Parameters.AddWithValue("@StockId", int.Parse(stockId));
                                cm.ExecuteNonQuery();
                            }

                            // Update cart status
                            using (SqlCommand cm = new SqlCommand("UPDATE tblCart SET Status = 'Sold' WHERE CartId = @CartId", cn, transaction))
                            {
                                cm.Parameters.AddWithValue("@CartId", int.Parse(cartId));
                                cm.ExecuteNonQuery();
                            }
                        }

                        // Record the sale transaction
                        RecordSaleTransaction(cn, transaction);

                        // Commit transaction
                        transaction.Commit();
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        MessageBox.Show("Error processing payment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                frmPrintReceipt frm = new frmPrintReceipt(fm);
                frm.LoadReport(txtTendered.Text, txtBalance.Text);
                frm.ShowDialog();
                MessageBox.Show("Payment successfully saved!", "Payment", MessageBoxButtons.OK, MessageBoxIcon.Information);
                fm.LoadCart();
                fm.GetInvoice();
                this.Dispose();
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid number format. Please check your inputs!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error processing payment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
              
        }


        private void RecordSaleTransaction(SqlConnection cn, SqlTransaction transaction)
        {
            try
            {
                // Insert into tblSales (each product line from tblCart)
                string salesQuery = @"
        INSERT INTO tblSales (ProductID, InvoiceNo, BrandId, GenericId, ClassificationId, TypeId, FormulationId, Price, Qty, Discount, LineTotal, PaymentMode)
        SELECT 
            c.ProductID,
            c.InvoiceNo,
            p.BrandId,
            p.GenericId,
            p.ClassificationId,
            p.TypeId,
            p.FormulationId,
            c.Price,
            c.Qty,
            c.Discount,
            (c.Price * c.Qty) - c.Discount,
            @PaymentMode
        FROM tblCart c
        INNER JOIN tblProducts p ON c.ProductId = p.ProductID
        WHERE c.InvoiceNo = @InvoiceNo AND c.Status = 'Sold'";

                using (SqlCommand cm = new SqlCommand(salesQuery, cn, transaction))
                {
                    cm.Parameters.AddWithValue("@InvoiceNo", fm.lblIvoiceNo.Text);
                    cm.Parameters.AddWithValue("@PaymentMode", cmboPaymentMode.Text);
                    cm.ExecuteNonQuery();
                }

                // Insert summary row into tblSalesDetail (using form total)
                string detailQuery = @"
        INSERT INTO tblSalesDetail (InvoiceNo, SalesDate, Total, ServedBy, Vat)
        SELECT  
            s.InvoiceNo,
            @SalesDate,
            @Total,
            @ServedBy,
            @Vat
        FROM tblSales s
        WHERE s.InvoiceNo = @InvoiceNo
        GROUP BY s.InvoiceNo";

                using (SqlCommand cm = new SqlCommand(detailQuery, cn, transaction))
                {
                    cm.Parameters.AddWithValue("@InvoiceNo", fm.lblIvoiceNo.Text);
                    cm.Parameters.AddWithValue("@SalesDate", fm.dtTransactionDate.Value);

                    decimal total;
                    if (!decimal.TryParse(fm.lblDueTotal.Text.Trim(), out total))
                        total = 0;
                    cm.Parameters.AddWithValue("@Total", total);

                    cm.Parameters.AddWithValue("@ServedBy", Convert.ToInt32(fm.lblUser.Tag));
                    cm.Parameters.AddWithValue("@Vat", fm.lblVat.Text);

                    cm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error recording sale: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                throw; // rollback
            }
        }



//        private void RecordSaleTransaction(SqlConnection cn, SqlTransaction transaction)
//        {
//            try
//            {
//                // Insert into tblSales (each product line from tblCart)
//                string salesQuery = @"
//        INSERT INTO tblSales (ProductID, InvoiceNo, BrandId, GenericId, ClassificationId, TypeId, FormulationId, Price, Qty,Discount, LineTotal)
//        SELECT 
//            c.ProductID,
//            c.InvoiceNo,
//            p.BrandId,
//            p.GenericId,
//            p.ClassificationId,
//            p.TypeId,
//            p.FormulationId,
//            c.Price,
//            c.Qty,
//             c.Discount,
//            (c.Price * c.Qty)- c.Discount
//                   
//        FROM tblCart c
//        INNER JOIN tblProducts p ON c.ProductId = p.ProductID
//        WHERE c.InvoiceNo = @InvoiceNo AND c.Status = 'Sold'";

//                using (SqlCommand cm = new SqlCommand(salesQuery, cn, transaction))
//                {
//                    cm.Parameters.AddWithValue("@InvoiceNo", fm.lblIvoiceNo.Text);
//                    cm.Parameters.AddWithValue("@PaymentMode", cmboPaymentMode.Text);
//                    cm.ExecuteNonQuery();
//                }

//                // Insert summary row into tblSalesDetail (using form total)
//                string detailQuery = @"
//        INSERT INTO tblSalesDetail (InvoiceNo, SalesDate, Total, ServedBy)
//        SELECT  
//            s.InvoiceNo,
//            @SalesDate,
//            @Total,
//            @ServedBy
//        FROM tblSales s
//        WHERE s.InvoiceNo = @InvoiceNo
//        GROUP BY s.InvoiceNo";

//                using (SqlCommand cm = new SqlCommand(detailQuery, cn, transaction))
//                {
//                    cm.Parameters.AddWithValue("@InvoiceNo", fm.lblIvoiceNo.Text);
//                    cm.Parameters.AddWithValue("@SalesDate", fm.dtTransactionDate.Value);
//                    cm.Parameters.AddWithValue("@Vat", fm.lblVat.Text);
//                    // convert lblDueTotal safely to decimal
//                    decimal total;
//                    if (!decimal.TryParse(fm.lblDueTotal.Text.Trim(), out total))
//                        total = 0;
//                    cm.Parameters.AddWithValue("@Total", total);
//                    cm.Parameters.AddWithValue("@ServedBy", Convert.ToInt32(fm.lblUser.Tag));
//                  //  cm.Parameters.AddWithValue("@ServedBy", fm.lblUser.Text); // cashier NAME
//                    cm.ExecuteNonQuery();
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error recording sale: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//                throw; // rollback
//            }
//        }





        }


        }
       
        
    

