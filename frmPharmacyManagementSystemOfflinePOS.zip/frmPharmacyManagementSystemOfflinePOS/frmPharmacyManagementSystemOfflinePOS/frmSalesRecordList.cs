﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmSalesRecordList : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        public frmSalesRecordList()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
         //  LoadTopSellingRecord();
          // LoadSalesRecord();
        }

        private void btnLoadSold_Click(object sender, EventArgs e)
        {
            try
            {
                int i = 0;
                double _total = 0;
                double _totalvat = 0;
                double _profit = 0;
                dataGridView2.Rows.Clear();

                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    string sql = @"
                SELECT 
                    s.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    SUM(s.Qty) AS TotalQty,
                    SUM(s.LineTotal) AS TotalAmount,
                    SUM(sd.Vat) AS TotalVat,
                    p.CostPrice,
                    p.SellingPrice,
                    p.Profit AS UnitProfit
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                INNER JOIN tblProducts p ON s.ProductID = p.ProductID
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0
            ";

                    // Filter by date
                    if (dt3.Value.Date == dt4.Value.Date)
                    {
                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
                    }
                    else
                    {
                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
                    }

                    sql += @"
                GROUP BY 
                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName, 
                    p.CostPrice, p.SellingPrice, p.Profit
                ORDER BY SUM(s.Qty) DESC"; // highest selling first

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@date1", dt3.Value.Date);

                        if (dt3.Value.Date != dt4.Value.Date)
                        {
                            cmd.Parameters.AddWithValue("@date2", dt4.Value.Date.AddDays(1).AddSeconds(-1));
                        }

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                double lineTotal = Convert.ToDouble(dr["TotalAmount"]);
                                double TotalVat = Convert.ToDouble(dr["TotalVat"]);
                                int qty = Convert.ToInt32(dr["TotalQty"]);

                                // Calculate profit per line
                                double unitProfit = Convert.ToDouble(dr["UnitProfit"]);
                                double lineProfit = unitProfit * qty;

                                _total += lineTotal;
                                _totalvat += TotalVat;
                                _profit += lineProfit;

                                dataGridView2.Rows.Add(
                                    i,
                                    dr["ProductID"].ToString(),
                                    dr["Brand"].ToString(),
                                    dr["Generic"].ToString(),
                                    dr["Classification"].ToString(),
                                    dr["TypeName"].ToString(),
                                    dr["FormulationName"].ToString(),
                                    qty.ToString(),
                                    lineTotal.ToString("#,##0.00"),
                                    TotalVat.ToString("#,##0.00"),
                                    lineProfit.ToString("#,##0.00") // new column for profit per product
                                );
                            }
                        }
                    }
                }

                lblVAT.Text = _totalvat.ToString("#,##0.00");
                lblProfit.Text = _profit.ToString("#,##0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

//            try
//            {
//                int i = 0;
//                double _total = 0;
//                double _totalvat = 0;
//                double _profit = 0;
//                dataGridView2.Rows.Clear();

//                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
//                {
//                    connection.Open();

//                    string sql = @"
//                SELECT 
//                    s.ProductID,
//                    b.Brand,
//                    g.Generic,
//                    c.Classification,
//                    t.TypeName,
//                    f.FormulationName,
//                    SUM(s.Qty) AS TotalQty,
//                    SUM(s.LineTotal) AS TotalAmount,
//                    SUM(sd.Vat) AS TotalVat
//                FROM tblSales s
//                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
//                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
//                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
//                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
//                LEFT JOIN tblType t ON s.TypeId = t.TypeID
//                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
//                WHERE s.Qty > 0
//            ";

//                    // Filter by date
//                    if (dt3.Value.Date == dt4.Value.Date)
//                    {
//                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
//                    }
//                    else
//                    {
//                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
//                    }

//                    sql += @"
//                GROUP BY 
//                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName
//                ORDER BY SUM(s.Qty) DESC"; // highest selling first

//                    using (SqlCommand cmd = new SqlCommand(sql, connection))
//                    {
//                        cmd.Parameters.AddWithValue("@date1", dt3.Value.Date);

//                        if (dt3.Value.Date != dt4.Value.Date)
//                        {
//                            cmd.Parameters.AddWithValue("@date2", dt4.Value.Date.AddDays(1).AddSeconds(-1));
//                        }

//                        using (SqlDataReader dr = cmd.ExecuteReader())
//                        {
//                            while (dr.Read())
//                            {
//                                i++;
//                                double lineTotal = Convert.ToDouble(dr["TotalAmount"]);
//                                double TotalVat = Convert.ToDouble(dr["TotalVat"]);

//                                _total += lineTotal;
//                                _totalvat += TotalVat;
                               
//                                dataGridView2.Rows.Add(
//                                    i,
//                                    dr["ProductID"].ToString(),
//                                    dr["Brand"].ToString(),
//                                    dr["Generic"].ToString(),
//                                    dr["Classification"].ToString(),
//                                    dr["TypeName"].ToString(),
//                                    dr["FormulationName"].ToString(),
//                                    dr["TotalQty"].ToString(),
//                                    lineTotal.ToString("#,##0.00"),
//                                    TotalVat.ToString("#,##0.00")
//                                );
//                            }
//                        }
//                    }
//                }

//                lblVAT.Text = _totalvat.ToString("#,##0.00");
//                lblProfit.Text = _profit.ToString("#,##0.00");
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }
           // LoadSalesRecord();
        }

        public void LoadTopSellingRecord()
        {
            try
            {
                int i = 0;
                double _total = 0;
                dataGridView1.Rows.Clear();

                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    string sql = @"
                SELECT TOP 10
                    s.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    SUM(s.Qty) AS TotalQty,
                    SUM(s.LineTotal) AS TotalSales
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0
            ";

                    // Filter by date
                    if (dt1.Value.Date == dt2.Value.Date)
                    {
                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
                    }
                    else
                    {
                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
                    }

                    sql += @"
                GROUP BY 
                    s.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName
                ORDER BY SUM(s.Qty) DESC";  // Order by quantity sold (best-sellers first)

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@date1", dt1.Value.Date);

                        if (dt1.Value.Date != dt2.Value.Date)
                        {
                            cmd.Parameters.AddWithValue("@date2", dt2.Value.Date.AddDays(1).AddSeconds(-1));
                        }

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                double lineTotal = Convert.ToDouble(dr["TotalSales"]);                            
                               _total += lineTotal;                             
                                dataGridView1.Rows.Add(
                                    i,
                                    dr["ProductID"].ToString(),
                                   // dr["Brand"].ToString(),
                                    dr["Generic"].ToString(),
                                   // dr["Classification"].ToString(),
                                    //dr["TypeName"].ToString(),
                                  //  dr["FormulationName"].ToString(),
                                    dr["TotalQty"].ToString(),
                                    lineTotal.ToString("#,##0.00")
                                );
                            }
                        }
                    }
                }

                // lblTotal.Text = _total.ToString("#,##0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SalesSummaryReportView frm = new SalesSummaryReportView(this);
            frm.LoadSalesSummaryReport();
            frm.ShowDialog();
        }


        //public void LoadSalesRecord()
        //{
           
        //}


        private void dt3_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void dt4_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadTopSellingRecord();
        }

        private void dt1_ValueChanged(object sender, EventArgs e)
        {
            //LoadTopSellingRecord();
        }

        private void dt2_ValueChanged(object sender, EventArgs e)
        {
           // LoadTopSellingRecord();
        }
    }
}
