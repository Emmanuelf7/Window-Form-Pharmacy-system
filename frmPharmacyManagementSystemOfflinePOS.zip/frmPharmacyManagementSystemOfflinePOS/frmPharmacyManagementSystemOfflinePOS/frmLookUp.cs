﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmLookUp : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmSales f;
        private int i = 0;
        public frmLookUp(frmSales flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.f = flist;
            LoadProduct();
        }

        public void LoadProduct()
        {
            try
            {
                i = 0;
                dataGridView2.Rows.Clear();

                string searchText = string.IsNullOrEmpty(txtSearch.Text) ? "" : txtSearch.Text;

                string query = @"
            SELECT 
                p.ProductID,                      
                b.Brand,
                g.Generic,
                c.Classification,
                t.TypeName,
                f.FormulationName,              
                ISNULL(si.TotalStockIn, 0) AS StockInQty,            
                p.SellingPrice
            FROM tblProducts AS p
            INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
            INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
            INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
            INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
            INNER JOIN tblType AS t ON p.TypeId = t.TypeID
            LEFT JOIN (
                SELECT productId, SUM(StockInQty) AS TotalStockIn
                FROM tblStockIn
                GROUP BY productId
            ) si ON p.ProductID = si.productId
            WHERE b.Brand LIKE '%' + @SearchText + '%'
               OR g.Generic LIKE '%' + @SearchText + '%'
               OR c.Classification LIKE '%' + @SearchText + '%'
            ORDER BY p.ProductID";

                cn.Open();
                cm = new SqlCommand(query, cn);
                cm.Parameters.AddWithValue("@SearchText", searchText);
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    i++;
                    dataGridView2.Rows.Add(
                        i,
                        dr["ProductID"].ToString(),
                        dr["Brand"].ToString(),
                        dr["Generic"].ToString(),
                        dr["Classification"].ToString(),
                        dr["TypeName"].ToString(),
                        dr["FormulationName"].ToString(),
                        dr["StockInQty"].ToString(),   // ✅ This is now the SUM of all StockInQty
                        dr["SellingPrice"].ToString()
                    );
                }
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        private void CustomizeDataGridView()
        {
            dataGridView2.BorderStyle = BorderStyle.None;
            dataGridView2.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(238, 239, 249);
            dataGridView2.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView2.DefaultCellStyle.SelectionBackColor = Color.SeaGreen;
            dataGridView2.DefaultCellStyle.SelectionForeColor = Color.WhiteSmoke;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.EnableHeadersVisualStyles = false;
            dataGridView2.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView2.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(20, 25, 72);
            dataGridView2.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            txtSearch.Clear();
            LoadProduct();
        }
  

        private void frmLookUp_Load(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void txtSearch_TextChanged_1(object sender, EventArgs e)
        {
            LoadProduct();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "ColAdd")
            {
                frmQty frm = new frmQty(f);
                frm.ProductDetails(dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString(), dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString(), dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString(), dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString(), dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString(), f.lblIvoiceNo.Text, dataGridView2.Rows[e.RowIndex].Cells[6].Value.ToString(), int.Parse(dataGridView2.Rows[e.RowIndex].Cells[7].Value.ToString()), Decimal.Parse(dataGridView2.Rows[e.RowIndex].Cells[8].Value.ToString()));
                frm.ShowDialog();
            }

        }
    }
}
