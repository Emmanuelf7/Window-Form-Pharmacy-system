﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_Generic : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        frmMaintenance fm;
        SqlDataReader dr;
        public frm_Generic(frmMaintenance flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm = flist;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
            txt_Generic.Clear();
            txt_Generic.Focus();
            return;
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {           

            try
            {
                bool found = false;
                cn.Open();
                cm = new SqlCommand("select * from tblGeneric where Generic like @Generic", cn);
                cm.Parameters.AddWithValue("@Generic", "%" + txt_Generic.Text + "%");
                dr = cm.ExecuteReader(); // Initialize the SqlDataReader here
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        found = true;
                    }
                }
                dr.Close();
                cn.Close();
                if (found == false)
                {
                    if (MessageBox.Show("Please confirm if you want to save this generic?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("INSERT INTO tblGeneric(Generic) VALUES(@Generic)", cn);
                        cm.Parameters.AddWithValue("@Generic", txt_Generic.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        Clear();
                        fm.LoadGeneric();
                        MessageBox.Show("Generic name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Error: Duplicate entry!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update this generic name?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblGeneric SET Generic=@Generic where GenericID like '" + lblGenericID.Text + "'", cn);
                    cm.Parameters.AddWithValue("@Generic", txt_Generic.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Brand name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    fm.LoadGeneric();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
