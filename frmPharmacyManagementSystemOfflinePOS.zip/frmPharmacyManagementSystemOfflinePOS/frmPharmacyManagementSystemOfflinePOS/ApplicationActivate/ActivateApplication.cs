﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS.ApplicationActivate
{
    public partial class ActivateApplication : Form
    {
       //private DateTime trialExpirationDate;
       // private string activationKey = "1234-5678-ABCD-EFGH"; // Example activation key
       // private const string trialFile = "trial_info.txt";

        private string activationKey = "1234-5678-ABCD-EFGH"; // Example activation key
        private const string trialFile = "trial_info.txt";
        private Form1.UpdateTrialStatusDelegate _updateStatusDelegate;

        public ActivateApplication(Form1.UpdateTrialStatusDelegate updateStatusDelegate)
        {
            InitializeComponent();
            _updateStatusDelegate = updateStatusDelegate;  // Assign the delegate
        }

        // Reset Trial button click event
        private void btnActivate_Click(object sender, EventArgs e)
        {

             string enteredKey = txtActivationKey.Text;

            if (enteredKey == activationKey)
            {
                // After activation, set the expiration date to DateTime.MaxValue (9999-12-31)
                string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, trialFile);
                File.WriteAllLines(filePath, new[] { DateTime.MaxValue.ToString() });

                MessageBox.Show("Activation successful! The app will no longer expire.");

                // Call the delegate to update the status on MainForm
                _updateStatusDelegate.Invoke("Activated.");
                this.Close(); // Close the activation form
            }
            else
            {
                MessageBox.Show("Invalid activation key.");
            }
        }

        
        // Reset Trial button click event
        private void btnReset_Click(object sender, EventArgs e)
        {
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, trialFile);

            if (File.Exists(filePath))
            {
                // Load the current expiration date from the file
                string[] data = File.ReadAllLines(filePath);
                DateTime expirationDate = DateTime.Parse(data[0]);

                if (expirationDate == DateTime.MaxValue)
                {
                    // If the app is permanently activated, reset the expiration date back to a trial (e.g., 30 days)
                    DateTime newExpirationDate = DateTime.Now.AddDays(30);
                    File.WriteAllLines(filePath, new[] { newExpirationDate.ToString() });

                    // Call the delegate to update the status on MainForm
                    _updateStatusDelegate.Invoke("Trial period has been reset. Your trial now ends on: " + newExpirationDate.ToShortDateString());
                    this.Close();  // Close the reset trial form
                }
                else
                {
                    MessageBox.Show("This application is still in its trial period.");
                }
            }
            else
            {
                MessageBox.Show("Trial information not found.");
            }
        }
    }
        }

      