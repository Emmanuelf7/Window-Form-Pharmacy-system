﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmMaintenance : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public frmMaintenance()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadClassification();
            LoadBrand();
            LoadGeneric();
            LoadType();
            LoadFormulation();
        }

        public void LoadClassification()
        {

            int i = 0;
            dataGridView1.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("select * from tblClassification order by Classification", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView1.Rows.Add(i, dr["ClassificationId"].ToString(), dr["Classification"].ToString());
            }
            dr.Close();
            cn.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frm_Classification frm = new frm_Classification(this);
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            LoadClassification();
            frm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView1.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit")
            {
                frm_Classification frm = new frm_Classification(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblCategoryId.Text = dataGridView1[1, e.RowIndex].Value.ToString();
                frm.txt_Category.Text = dataGridView1[2, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete")
            {
                if (MessageBox.Show("Please confirm if you want to delete this brand!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblClassification where ClassificationId like '" + dataGridView1[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Classification has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadClassification();
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            frm_Brand frm = new frm_Brand(this);
            LoadBrand();
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            frm.Show();
        }

        public void LoadBrand()
        {

            int i = 0;
            dataGridView2.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("select * from tblBrand order by Brand", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView2.Rows.Add(i, dr["BrandID"].ToString(), dr["Brand"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit1")
            {
                frm_Brand frm = new frm_Brand(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblBrandId.Text = dataGridView2[1, e.RowIndex].Value.ToString();
                frm.txt_Brand.Text = dataGridView2[2, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete1")
            {
                if (MessageBox.Show("Please confirm if you want to delete this brand!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblBrand where BrandID like '" + dataGridView2[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Brand has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBrand();
                }
            }
        }

        public void LoadGeneric()
        {

            int i = 0;
            dataGridView3.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("select * from tblGeneric order by Generic", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView3.Rows.Add(i, dr["GenericID"].ToString(), dr["Generic"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView3.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit2")
            {
                frm_Generic frm = new frm_Generic(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblGenericID.Text = dataGridView3[1, e.RowIndex].Value.ToString();
                frm.txt_Generic.Text = dataGridView3[2, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete2")
            {
                if (MessageBox.Show("Please confirm if you want to delete this brand!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblGeneric where GenericID like '" + dataGridView3[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Generic has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadGeneric();
                }
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            frm_Generic frm = new frm_Generic(this);
            LoadGeneric();
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            frm.Show();
        }

        public void LoadType()
        {

            int i = 0;
            dataGridView5.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("select * from tblType order by TypeName", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView5.Rows.Add(i, dr["TypeID"].ToString(), dr["TypeName"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataGridView5_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView5.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit3")
            {
                frm_Type frm = new frm_Type(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblTypeID.Text = dataGridView5[1, e.RowIndex].Value.ToString();
                frm.txt_Type.Text = dataGridView5[2, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete3")
            {
                if (MessageBox.Show("Please confirm if you want to delete this medicine type!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblType where TypeID like '" + dataGridView5[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Medicine type has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadType();
                }
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            frm_Type frm = new frm_Type(this);
            LoadType();
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            frm.Show();
        }

        public void LoadFormulation()
        {

            int i = 0;
            dataGridView4.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("select * from tblFormulation order by FormulationName", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                dataGridView4.Rows.Add(i, dr["FormulationID"].ToString(), dr["FormulationName"].ToString());
            }
            dr.Close();
            cn.Close();
        }
        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView4.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit4")
            {
                frm_Formulation frm = new frm_Formulation(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblFormulation.Text = dataGridView4[1, e.RowIndex].Value.ToString();
                frm.txt_Formulation.Text = dataGridView4[2, e.RowIndex].Value.ToString();
                frm.ShowDialog();
            }
            else if (ColName == "Delete4")
            {
                if (MessageBox.Show("Please confirm if you want to delete this formulation!", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblFormulation where FormulationID like '" + dataGridView4[1, e.RowIndex].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Formulation has been successfully deleted!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadFormulation();
                }
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            frm_Formulation frm = new frm_Formulation(this);
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            LoadFormulation();
            frm.Show();
        }

        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
          //  try
          //  {
                
          //      cn.Open();
          //      cm = new SqlCommand("select count(*) from tblVat", cn);
          //      dr = cm.ExecuteReader();
          //      //while (dr.Read())
          //      //{

          //      //    txtVat.Text = dr["Vat"].ToString();
          //      //}              
          //      cn.Close();

          ////  }
                 
            
          //  }
          //  catch (Exception ex)
          //  {
          //      cn.Close();
          //      MessageBox.Show(ex.Message);
          //  }

            try
            {
                cn.Open();
                SqlCommand cm = new SqlCommand("select count(*) from tblVat", cn);
                int icount = (int)cm.ExecuteScalar();
                cn.Close();
                if (icount > 0)
                {
                    cn.Open();
                    cm = new SqlCommand("update tblVat set vat= @vat", cn);
                    cm.Parameters.AddWithValue("@vat", double.Parse(txtVat.Text));
                    cm.ExecuteNonQuery();
                    cn.Close();
                }
                else
                {
                    cn.Open();
                    cm = new SqlCommand("insert into tblVat(vat)values(@vat)", cn);
                    cm.Parameters.AddWithValue("@vat", double.Parse(txtVat.Text));
                    cm.ExecuteNonQuery();
                    cn.Close();
                }
                MessageBox.Show("Vat has been successfully saved", "Information");
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void txtVat_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtVat_KeyPress(object sender, KeyPressEventArgs e)
        {
           // e.Handled = true;
        }
    }
}
