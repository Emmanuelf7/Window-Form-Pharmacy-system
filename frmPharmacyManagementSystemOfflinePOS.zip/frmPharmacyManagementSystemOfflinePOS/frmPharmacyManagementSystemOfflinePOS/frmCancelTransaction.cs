﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmCancelTransaction : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        public frmCancelTransaction()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadCancelledOrders();
        }

        public void LoadCancelledOrders()
        {
            try
            {
                int i = 0;
                dataGridView2.Rows.Clear();

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    string sql = @"
                SELECT 
                    c.CancelID,
                    c.InvoiceNo,
                    p.ProductID,
                    b.Brand,
                    g.Generic,
                    cl.Classification,
                    t.TypeName,
                    f.FormulationName,
                    c.Price,
                    c.Qty,
                    c.Total,
                    c.Sdate,
                    c.VoidBy,
                    c.cancelledby,
                    c.reason,
                    c.action
                FROM tblCancel AS c
                LEFT JOIN tblProducts AS p ON c.ProductId = p.ProductID
                LEFT JOIN tblBrand AS b ON c.BrandId = b.BrandID
                LEFT JOIN tblGeneric AS g ON c.GenericId = g.GenericID
                LEFT JOIN tblClassification AS cl ON c.ClassificationId = cl.ClassificationId
                LEFT JOIN tblType AS t ON c.TypeId = t.TypeID
                LEFT JOIN tblFormulation AS f ON c.FormulationId = f.FormulationID
                WHERE CAST(c.Sdate AS DATE) BETWEEN @date1 AND @date2
                ORDER BY c.Sdate DESC";

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    {
                        cm.Parameters.AddWithValue("@date1", dt1.Value.Date);
                        cm.Parameters.AddWithValue("@date2", dt2.Value.Date);

                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                dataGridView2.Rows.Add(
                                    i,
                                   dr["CancelID"].ToString(),                                  
                                    dr["ProductID"].ToString(),
                                     dr["InvoiceNo"].ToString(),
                                     Convert.ToDateTime(dr["Sdate"]).ToString("dd-MM-yyyy"),
                                    dr["Brand"].ToString(),
                                    dr["Generic"].ToString(),
                                    dr["Classification"].ToString(),
                                    dr["TypeName"].ToString(),
                                    dr["FormulationName"].ToString(),
                                    dr["Qty"].ToString(),
                                    Convert.ToDouble(dr["Price"]).ToString("#,##0.00"),
                                    Convert.ToDouble(dr["Total"]).ToString("#,##0.00"),
                                   
                                    dr["VoidBy"].ToString(),
                                  //  dr["cancelledby"].ToString(),
                                    dr["reason"].ToString(),
                                    dr["action"].ToString()
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading cancelled orders: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dt1_ValueChanged(object sender, EventArgs e)
        {
            LoadCancelledOrders();
        }

        private void dt2_ValueChanged(object sender, EventArgs e)
        {
            LoadCancelledOrders();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

    }
}
