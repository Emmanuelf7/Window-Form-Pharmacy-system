﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmExpensisList : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
       // SqlDataReader dr;
     //  frmExpensisForm f;
        public frmExpensisList()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
          //    f = fm;
            getAllExpensisRecord();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            frmExpensisForm frm = new frmExpensisForm(this);
            frm.btn_CreateNew.Enabled = true;
            frm.btnUpdateCategory.Enabled = false;
            getAllExpensisRecord();
            frm.ShowDialog();
            
        }

        public void getAllExpensisRecord()
        {
            int i = 0;
            dataGridView2.Rows.Clear();

            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    // ✅ Convert varchar date to real date for filtering, then back to dd-MM-yyyy for display
                    using (SqlCommand cm = new SqlCommand(@"
                SELECT ExpensisId, 
                       CONVERT(varchar(10), CONVERT(date, SDate, 105), 105) AS SDate, 
                       Description, 
                       Amount, 
                       Reason 
                FROM tblExpensis 
                WHERE CONVERT(date, SDate, 105) BETWEEN @date1 AND @date2", cn))
                    {
                        cm.Parameters.AddWithValue("@date1", dtExpensis1.Value.Date);
                        cm.Parameters.AddWithValue("@date2", dtExpensis2.Value.Date);

                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;

                                // Read already formatted date string (dd-MM-yyyy)
                                string expensisDate = dr["SDate"].ToString();

                                // Format amount
                                double amount = Convert.ToDouble(dr["Amount"]);
                                string formattedAmount = amount.ToString("#,##0.00");

                                // Add row to DataGridView
                                dataGridView2.Rows.Add(
                                    i,
                                    dr["ExpensisId"].ToString(),
                                    expensisDate,
                                    dr["Description"].ToString(),
                                    formattedAmount,
                                    dr["Reason"].ToString()
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void btnLoadData_Click(object sender, EventArgs e)
        {
            int i = 0;
            double total = 0; // for calculating total amount
            dataGridView2.Rows.Clear();

            try
            {
                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    using (SqlCommand cm = new SqlCommand(@"
                SELECT ExpensisId, 
                       CONVERT(varchar(10), CONVERT(date, SDate, 105), 105) AS SDate, 
                       Description, 
                       Amount, 
                       Reason
                FROM tblExpensis 
                WHERE CONVERT(date, SDate, 105) BETWEEN @date1 AND @date2", cn))
                    {
                        cm.Parameters.AddWithValue("@date1", dtExpensis1.Value.Date);
                        cm.Parameters.AddWithValue("@date2", dtExpensis2.Value.Date);

                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;

                                // Now SDate is already formatted as dd-MM-yyyy in SQL
                                string expensisDate = dr["SDate"].ToString();

                                // Format amount
                                double amount = Convert.ToDouble(dr["Amount"]);
                                string formattedAmount = amount.ToString("#,##0.00");

                                // Add row to DataGridView
                                dataGridView2.Rows.Add(
                                    i,
                                    dr["ExpensisId"].ToString(),
                                    expensisDate,
                                    dr["Description"].ToString(),
                                    formattedAmount,
                                    dr["Reason"].ToString()
                                );

                                // Add to total
                                total += amount;
                            }
                        }
                    }
                }

                // ✅ Show total in label
                lblTotal.Text = total.ToString("#,##0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (ColName == "Edit")
            {
                frmExpensisForm frm = new frmExpensisForm(this);
                frm.btn_CreateNew.Enabled = false;
                frm.btnUpdateCategory.Enabled = true;
                frm.lblID.Text = dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString();
                frm.dtDate.CustomFormat = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();
                frm.txt_Description.Text = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
                frm.txtAmount.Text = dataGridView2.Rows[e.RowIndex].Cells[4].Value.ToString();
                frm.txtReason.Text = dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString();
               
                frm.Show();
                getAllExpensisRecord();
            }
            else if (ColName == "Delete")
            {
                if (MessageBox.Show("DELETE THIS RECORD? CLICK YES TO CONFIRM", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("delete from tblExpensis where ExpensisId like '" + dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString() + "'", cn);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("The Record has been successfully deleted.");
                    getAllExpensisRecord();
                }
            }

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            
            frmPrintReportView frm = new frmPrintReportView();

            frm.LoadExpensis(
                "SELECT ExpensisId, " +
                "CONVERT(varchar(10), CONVERT(date, SDate, 105), 105) AS SDate, " +
                "Description, " +
                "Amount, " +
                "Reason, " +
                "SUM(Amount) AS Amount " +
                "FROM tblExpensis " +
                "WHERE CONVERT(date, SDate, 105) BETWEEN '" + dtExpensis1.Value.ToString("yyyy-MM-dd") + "' " +
                "AND '" + dtExpensis2.Value.ToString("yyyy-MM-dd") + "' " +
                "GROUP BY ExpensisId, SDate, Description, Amount, Reason",
                "From: " + dtExpensis1.Value.ToString("dd-MM-yyyy") +
                " - To: " + dtExpensis2.Value.ToString("dd-MM-yyyy")
            );

            frm.Show();

        }

    }
}
