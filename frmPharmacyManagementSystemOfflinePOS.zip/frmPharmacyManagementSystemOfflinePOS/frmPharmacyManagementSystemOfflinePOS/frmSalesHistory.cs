﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmSalesHistory : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        public string suser;
        public frmSalesHistory()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadCashier();
            LoadDailySalesRecord();
        }

        public void LoadCashier()
        {
            using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
            {
                cn.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT UserId, Username FROM tblUser WHERE role = 'Cashier'", cn);
                DataTable dt = new DataTable();
                da.Fill(dt);

                // Insert "All Cashier" option manually
                DataRow row = dt.NewRow();
                row["UserId"] = 0;  // special value
                row["Username"] = "All Cashier";
                dt.Rows.InsertAt(row, 0);

                cboCashier.DataSource = dt;
                cboCashier.DisplayMember = "Username";
                cboCashier.ValueMember = "UserId";
            }
        }


        public void LoadDailySalesRecord()
        {
            try
            {
                int i = 0;
                double _total = 0;
                dataGridView2.Rows.Clear();

                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    string sql = @"
                SELECT 
                    s.SalesID, 
                    s.InvoiceNo,
                    s.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    s.Price, 
                    s.Qty,
                    s.Discount,
                    s.LineTotal,                  
                    sd.SalesDate,
                    s.PaymentMode
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0"; // ADD THIS FILTER to exclude zero quantity items

                    // Filter by date
                    if (dt1.Value.Date == dt2.Value.Date)
                    {
                        sql += " AND CAST(sd.SalesDate AS DATE) = @date1";
                    }
                    else
                    {
                        sql += " AND sd.SalesDate BETWEEN @date1 AND @date2";
                    }

                    // Filter by cashier
                    if (cboCashier.Text != "All Cashier")
                    {
                        sql += " AND sd.ServedBy = @cashier";
                    }

                    using (SqlCommand cmd = new SqlCommand(sql, connection))
                    {
                        cmd.Parameters.AddWithValue("@date1", dt1.Value.Date);

                        if (dt1.Value.Date != dt2.Value.Date)
                        {
                            cmd.Parameters.AddWithValue("@date2", dt2.Value.Date.AddDays(1).AddSeconds(-1));
                        }

                        if (cboCashier.Text != "All Cashier")
                        {
                            cmd.Parameters.AddWithValue("@cashier", Convert.ToInt32(cboCashier.SelectedValue));
                        }

                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                double lineTotal = Convert.ToDouble(dr["LineTotal"]);
                                _total += lineTotal;

                                dataGridView2.Rows.Add(
                                    i,
                                    dr["SalesID"].ToString(),
                                    dr["ProductID"].ToString(),
                                    dr["InvoiceNo"].ToString(),
                                    Convert.ToDateTime(dr["SalesDate"]).ToString("dd-MM-yyyy"),
                                    dr["Brand"].ToString(),
                                    dr["Generic"].ToString(),
                                    dr["Classification"].ToString(),
                                    dr["TypeName"].ToString(),
                                    dr["FormulationName"].ToString(),
                                    dr["Qty"].ToString(),
                                    dr["Price"].ToString(),
                                    dr["Discount"].ToString(),
                                    lineTotal.ToString("#,##0.00"),
                                     dr["PaymentMode"].ToString()
                                );
                            }
                        }
                    }
                }

                lblTotal.Text = _total.ToString("#,##0.00");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }





        private void frmSalesHistory_Load(object sender, EventArgs e)
        {
            LoadDailySalesRecord();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            string colName = dataGridView2.Columns[e.ColumnIndex].Name;
            if (colName == "colCancel")
            {
                frmCancelDetails frm = new frmCancelDetails(this);
                frm.txtID.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvProdID"].Value.ToString();
                frm.txtProductID.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvID"].Value.ToString();
                frm.txtInvoiceNo.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvReceiptNo"].Value.ToString();
             //   frm.txtDate.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvDate"].Value.ToString();
                frm.txtBrand.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvBrand"].Value.ToString();
                frm.txtGeneric.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvGeneric"].Value.ToString();
                frm.txtClassification.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvClassification"].Value.ToString();
                frm.txtType.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvType"].Value.ToString();
                frm.txtFormation.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvFormation"].Value.ToString();
                frm.txtQty.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvQty"].Value.ToString();
                frm.txtPrice.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvPrice"].Value.ToString();

                frm.txtDiscount.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvDiscount"].Value.ToString();
                frm.txtTotal.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvTotal"].Value.ToString();
                frm.cmboPaymentMode.Text = dataGridView2.Rows[e.RowIndex].Cells["dgvPaymentMode"].Value.ToString();
             //  frm.txtVoid.Text = suser;
                frm.txtCancel.Text = suser;
                frm.Show();
            }
        }

        private void dt1_ValueChanged(object sender, EventArgs e)
        {
            LoadDailySalesRecord();
        }

        private void dt2_ValueChanged(object sender, EventArgs e)
        {
            LoadDailySalesRecord();
        }

        private void cboCashier_SelectedIndexChanged(object sender, EventArgs e)
        {
           // LoadDailySalesRecord();
        }

        private void cboCashier_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            frmSalesHistoryReport frm = new frmSalesHistoryReport(this);
            frm.LoadSalesHistoryReport();
            frm.ShowDialog();
        }

    }
}
