﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmQty : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        private int productId;
        private decimal price;
        private string invoiceNo;

        private String pcode;
       
        private int qty;
        private String transno;
        string stitle = "POS System";
        frmSales fSales;

        public frmQty(frmSales fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fSales = fm;

        }

        public void ProductDetails(String pcode, decimal price, String transno, int qty)
        {
            this.pcode = pcode;
            this.price = price;
            this.transno = transno;
            this.qty = qty;
        }
        private void frmQty_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
            txtQty.Focus();
            txtQty.SelectionStart = 0;
            txtQty.SelectionLength = txtQty.Text.Length; 

        }

        public void ProductDetails(
                    string productId,
                    string productName,
                    string brand,
                    string category,
                    string description,
                    string invoiceNo,
                    string barcode,
                    int qty,
                    decimal price)
        {
            this.productId = int.Parse(productId);
            this.price = price;
            this.invoiceNo = invoiceNo;

            // Store the extra details if you need them
            //this.productName = productName;
            //this.brand = brand;
            //this.category = category;
            //this.description = description;
            //this.barcode = barcode;
            //this.qty = qty;
        }

        public void productDetails(String productId, Decimal price, String invoiceNo)
        {
            this.productId = int.Parse(productId);
            this.price = price;
            this.invoiceNo = invoiceNo;


        }

        private void frmQty_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13 && !string.IsNullOrEmpty(txtQty.Text))
            {
                try
                {
                    // Validate qty
                    int qty;
                    if (!int.TryParse(txtQty.Text.Trim(), out qty) || qty <= 0)
                    {
                        MessageBox.Show("Please enter a valid quantity (whole number greater than 0).",
                            stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    cn.Open();

                    // 1. Check if this product already exists in the cart for this invoice
                    string checkSql = @"SELECT CartId, Qty 
                                FROM tblCart 
                                WHERE InvoiceNo = @InvoiceNo 
                                  AND ProductId = @ProductId 
                                  AND Status = 'Pending'";

                    string existingCartId = null;
                    int existingQty = 0;

                    using (SqlCommand checkCmd = new SqlCommand(checkSql, cn))
                    {
                        checkCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
                        checkCmd.Parameters.AddWithValue("@ProductId", productId);

                        using (SqlDataReader dr = checkCmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                existingCartId = dr["CartId"].ToString();
                                existingQty = Convert.ToInt32(dr["Qty"]);
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(existingCartId))
                    {
                        // 2. Update existing row
                        int newQty = existingQty + qty;
                        string updateSql = @"UPDATE tblCart 
                                     SET Qty = @Qty, LineTotal = Price * @Qty 
                                     WHERE CartId = @CartId";

                        using (SqlCommand updateCmd = new SqlCommand(updateSql, cn))
                        {
                            updateCmd.Parameters.AddWithValue("@Qty", newQty);
                            updateCmd.Parameters.AddWithValue("@CartId", existingCartId);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // 3. Insert new row if product not found
                        string insertSql = @"INSERT INTO tblCart 
                                    (InvoiceNo, ProductId, Price, Qty, LineTotal, Sdate, Status) 
                                    VALUES (@InvoiceNo, @ProductId, @Price, @Qty, @Price * @Qty, @Sdate, 'Pending')";

                        using (SqlCommand insertCmd = new SqlCommand(insertSql, cn))
                        {
                            insertCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
                            insertCmd.Parameters.AddWithValue("@ProductId", productId);
                            insertCmd.Parameters.AddWithValue("@Price", price);
                            insertCmd.Parameters.AddWithValue("@Qty", qty);
                            insertCmd.Parameters.AddWithValue("@Sdate", fSales.dtTransactionDate.Value.Date); // ✅ Date type
                            insertCmd.ExecuteNonQuery();
                        }
                    }

                    cn.Close();

                    MessageBox.Show("Product quantity has been successfully added",
                        stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Reset search and refresh cart
                    fSales.txt_Search.Clear();
                    fSales.txt_Search.Focus();
                    fSales.LoadCart();

                    this.Dispose();
                }
                catch (Exception ex)
                {
                    if (cn.State == ConnectionState.Open)
                        cn.Close();

                    MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

//            if (e.KeyChar == 13 && !string.IsNullOrEmpty(txtQty.Text))
//            {
//                try
//                {
//                    cn.Open();

//                    // 1. Check if this product already exists in the cart for this invoice
//                    string checkSql = @"SELECT CartId, Qty 
//                                FROM tblCart 
//                                WHERE InvoiceNo = @InvoiceNo 
//                                  AND ProductId = @ProductId 
//                                  AND Status = 'Pending'";

//                    string existingCartId = null;
//                    int existingQty = 0;

//                    using (SqlCommand checkCmd = new SqlCommand(checkSql, cn))
//                    {
//                        checkCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
//                        checkCmd.Parameters.AddWithValue("@ProductId", productId);

//                        using (SqlDataReader dr = checkCmd.ExecuteReader())
//                        {
//                            if (dr.Read())
//                            {
//                                existingCartId = dr["CartId"].ToString();
//                                existingQty = Convert.ToInt32(dr["Qty"]);
//                            }
//                        }
//                    }

//                    if (!string.IsNullOrEmpty(existingCartId))
//                    {
//                        // 2. Update existing row
//                        int newQty = existingQty + int.Parse(txtQty.Text);
//                        string updateSql = @"UPDATE tblCart 
//                                     SET Qty = @Qty, Total = Price * @Qty 
//                                     WHERE CartId = @CartId";

//                        using (SqlCommand updateCmd = new SqlCommand(updateSql, cn))
//                        {
//                            updateCmd.Parameters.AddWithValue("@Qty", newQty);
//                            updateCmd.Parameters.AddWithValue("@CartId", existingCartId);
//                            updateCmd.ExecuteNonQuery();
//                        }
//                    }
//                    else
//                    {
//                        // 3. Insert new row if product not found
//                        string insertSql = @"INSERT INTO tblCart 
//                        (InvoiceNo, ProductId, Price, Qty, Sdate, Status) 
//                        VALUES (@InvoiceNo, @ProductId, @Price, @Qty, @Sdate, 'Pending')";

//                        using (SqlCommand insertCmd = new SqlCommand(insertSql, cn))
//                        {
//                            insertCmd.Parameters.AddWithValue("@InvoiceNo", invoiceNo);
//                            insertCmd.Parameters.AddWithValue("@ProductId", productId);
//                            insertCmd.Parameters.AddWithValue("@Price", price);
//                            insertCmd.Parameters.AddWithValue("@Qty", int.Parse(txtQty.Text));
//                            insertCmd.Parameters.AddWithValue("@Sdate", fSales.dtTransactionDate.Value);
//                         //   cm.Parameters.AddWithValue("@cashier", fSales.lblUser.Text);
//                            insertCmd.ExecuteNonQuery();
//                        }
//                    }

//                    cn.Close();

//                    MessageBox.Show("Product quantity has been successfully added", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);

//                    // Reset search and refresh cart
//                    fSales.txt_Search.Clear();
//                    fSales.txt_Search.Focus();
//                    fSales.LoadCart();

//                    this.Dispose();
//                }
//                catch (Exception ex)
//                {
//                    cn.Close();
//                    MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
//                }
         //   }

           

            }
            

            }
        }
  //  }

