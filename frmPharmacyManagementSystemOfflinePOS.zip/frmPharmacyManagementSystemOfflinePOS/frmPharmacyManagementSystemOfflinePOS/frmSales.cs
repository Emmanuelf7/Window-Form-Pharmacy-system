﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tulpep.NotificationWindow;
namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmSales : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        String id;
        String price;
        //int qty;

        string stitle = "POS System";
        public frmSales()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.KeyPreview = true;
            NotifyExpiringProduct();
           
        }
        public void NotifyExpiringProduct()
        {
            string expiring = "";
            cn.Open();
            cm = new SqlCommand("select count(*) as ExpiringProductCount from tblProducts where ExpiringDate <= DATEADD(day,30, GETDATE())", cn);
            string count = cm.ExecuteScalar().ToString();
            cn.Close();

            int i = 0;
            cn.Open();
            // cm = new SqlCommand("select * from tblProduct", cn);
            cm = new SqlCommand("select * from tblProducts as p inner join tblBrand as b on p.BrandId=b.BrandID inner join tblClassification as c on p.ClassificationId=c.ClassificationId inner join tblFormulation as f on p.FormulationId=f.FormulationID inner join tblGeneric as g on p.GenericId=g.GenericID inner join tblType as t on p.TypeId=t.TypeID where ExpiringDate <= DATEADD(day,30, GETDATE())", cn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                i++;
                expiring += i + "." + dr["Generic"].ToString() + Environment.NewLine;

            }
            dr.Close();
            cn.Close();

            PopupNotifier popup = new PopupNotifier();
            popup.Image = Properties.Resources.close_button_icon;
            popup.TitleText = count + "Product(s) Will Soon Expire";
            popup.ContentText = expiring;
            popup.Popup();
        }
        private void lblVAtable_Click(object sender, EventArgs e)
        {

        }

        private void btn_New_Click(object sender, EventArgs e)
        {
            if (dataGridView2.Rows.Count > 0)
            {
                return;
            }
            GetInvoice();

            txt_Search.Enabled = true;
            btnProduct.Enabled = true;
            btnCancel.Enabled = true;
            btnDiscount.Enabled = true;
            btnDailySales.Enabled = true;
            txt_Search.Focus();
        }


      

        public void GetInvoice()
        {

            try
            {
                DateTime sdate = DateTime.UtcNow;                           
                cn.Open();
                 Random random = new Random();
                 var qry = "Select * from tlbCart where Invoice like '%" + sdate + "%' order by CartId desc"; Console.WriteLine(qry);
                dr = cm.ExecuteReader();
                dr.Read();
                if (dr.HasRows)
                {
                    var value = RandomString(10);
                    lblIvoiceNo.Text = value;
                }
                
                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();

                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "z0123456789a";
            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            lblTime.Text = DateTime.Now.ToString("hh:mm:ss tt");
            lblDate.Text = DateTime.Now.ToString("dd-MMMM-yyyy");
           
        }


       

       
        private void txt_Search_TextChanged(object sender, EventArgs e)
        {
          
   try
   {
      
       if (cn.State == ConnectionState.Open)
       {
           cn.Close(); // Close the previous connection
       }

       cn.Open();
       cm = new SqlCommand("SELECT * FROM tblProducts where Barcode like @Barcode", cn);
       cm.Parameters.AddWithValue("@Barcode", txt_Search.Text);
       dr = cm.ExecuteReader();
       if (dr.Read())
       {
         //  string sellingPrice = dr["SellingPrice"].ToString();
          // string productID = dr["ProductID"].ToString();


          // dr.Close(); // Close the reader
          // cn.Close(); // Close the connection


           frmQty frm = new frmQty(this);
          
           frm.productDetails(dr["ProductID"].ToString(), decimal.Parse(dr["SellingPrice"].ToString()), lblIvoiceNo.Text);
           frm.ShowDialog();
         



           dr.Close();
           cn.Close();
       }
       else
       {
           cn.Close();

         //  MessageBox.Show("No product found!", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
       }
       
   }
   catch (Exception ex)
   {
      
       cn.Close(); // Close the connection in case of an exception

       MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
   }


         //SearchProduct (txt_Search.Text);
       // LoadCart();
        }

        private double GetProductPrice(int productId)
        {
            double price = 0;
            try
            {
                cn.Open();
                cm = new SqlCommand("SELECT Price FROM tblProducts WHERE ProductID = @ProductID", cn);
                cm.Parameters.AddWithValue("@ProductID", productId);
                price = Convert.ToDouble(cm.ExecuteScalar());
                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return price;
        }

        private int GetStockId(int productId)
        {
            int stockId = 0;
            try
            {
                cn.Open();
                cm = new SqlCommand(@"
            SELECT TOP 1 StockId 
            FROM tblStockIn 
            WHERE ProductId=@ProductId AND StockInQty>0
            ORDER BY Sdate ASC", cn);
                cm.Parameters.AddWithValue("@ProductId", productId);
                object result = cm.ExecuteScalar();
                cn.Close();

                if (result != null)
                    stockId = Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return stockId;
        }


        private void AddProductToCart(int productId, int quantity)
        {
            try
            {
                double price = GetProductPrice(productId);
                double lineTotal = price * quantity;

                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    // ✅ Check if this product is already in the cart for this invoice
                    string checkSql = @"SELECT CartId, Qty FROM tblCart 
                                WHERE ProductId = @ProductId 
                                AND InvoiceNo = @InvoiceNo 
                                AND Status = 'Pending'";

                    string cartId = "";
                    int existingQty = 0;

                    using (SqlCommand checkCmd = new SqlCommand(checkSql, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@ProductId", productId);
                        checkCmd.Parameters.AddWithValue("@InvoiceNo", lblIvoiceNo.Text);

                        using (SqlDataReader dr = checkCmd.ExecuteReader())
                        {
                            if (dr.Read())
                            {
                                cartId = dr["CartId"].ToString();
                                existingQty = Convert.ToInt32(dr["Qty"]);
                            }
                        }
                    }

                    if (!string.IsNullOrEmpty(cartId))
                    {
                        // ✅ Update existing row
                        int newQty = existingQty + quantity;
                        double newTotal = price * newQty;

                        string updateSql = @"UPDATE tblCart 
                                     SET Qty = @Qty, LineTotal = @LineTotal
                                     WHERE CartId = @CartId";
                        using (SqlCommand updateCmd = new SqlCommand(updateSql, connection))
                        {
                            updateCmd.Parameters.AddWithValue("@Qty", newQty);
                            updateCmd.Parameters.AddWithValue("@LineTotal", newTotal);
                            updateCmd.Parameters.AddWithValue("@CartId", cartId);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else
                    {
                        // ✅ Insert new row
                        string insertSql = @"INSERT INTO tblCart 
                                 (InvoiceNo, ProductId, Qty, Price, LineTotal, Status) 
                                 VALUES (@InvoiceNo, @ProductId, @Qty, @Price, @LineTotal, 'Pending')";
                        using (SqlCommand insertCmd = new SqlCommand(insertSql, connection))
                        {
                            insertCmd.Parameters.AddWithValue("@InvoiceNo", lblIvoiceNo.Text);
                            insertCmd.Parameters.AddWithValue("@ProductId", productId);
                            insertCmd.Parameters.AddWithValue("@Qty", quantity);
                            insertCmd.Parameters.AddWithValue("@Price", price);
                            insertCmd.Parameters.AddWithValue("@LineTotal", lineTotal);
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                // ✅ Now reload cart
                LoadCart();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        public void LoadCart()
        {
            try
            {
                bool hasrecord = false;
                dataGridView2.Rows.Clear();
                int i = 0;
                double total = 0;
                double discount = 0;
                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();

                    string sql = @"SELECT 
                ca.CartId,
                p.ProductID,
                b.Brand,
                g.Generic,
                c.Classification,
                t.TypeName,
                f.FormulationName,
                ca.Price,
                ca.Qty,
                ca.Discount,
                ca.LineTotal
            FROM tblCart as ca 
            INNER JOIN tblProducts as p ON p.ProductID=ca.ProductId 
            INNER JOIN tblBrand as b ON p.BrandId=b.BrandID 
            INNER JOIN tblClassification as c ON p.ClassificationId=c.ClassificationId 
            INNER JOIN tblFormulation as f ON p.FormulationId=f.FormulationID 
            INNER JOIN tblGeneric as g ON p.GenericId=g.GenericID 
            INNER JOIN tblType as t ON p.TypeId=t.TypeID 
            WHERE ca.InvoiceNo = @InvoiceNo AND ca.Status = 'Pending'
            ORDER BY p.ProductID";

                    using (SqlCommand cm = new SqlCommand(sql, connection))
                    {
                        cm.Parameters.AddWithValue("@InvoiceNo", lblIvoiceNo.Text);
                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                total += Convert.ToDouble(dr["LineTotal"]) - Convert.ToDouble(dr["Discount"]);
                                discount += Convert.ToDouble(dr["Discount"]);
                                dataGridView2.Rows.Add(
                                    i,
                                    dr["CartId"].ToString(),
                                    dr["Brand"].ToString(),
                                    dr["Generic"].ToString(),
                                    dr["Classification"].ToString(),
                                    dr["TypeName"].ToString(),
                                    dr["FormulationName"].ToString(),
                                    dr["Price"].ToString(),
                                    dr["Qty"].ToString(),
                                    dr["Discount"].ToString(),
                                   // Convert.ToDouble(dr["LineTotal"]).ToString("#,##0.00"),
                                   (Convert.ToDouble(dr["LineTotal"]) - Convert.ToDouble(dr["Discount"])).ToString("#,##0.00"),
                                    "[ + ]",
                                    "[ - ]"
                                );
                                hasrecord = true;
                            }
                        }
                    }
                }



                lblSubTotal.Text = total.ToString("#,##0.00");
                lblDiscount.Text = discount.ToString("#,##0.00");
                lblVat.Text = total.ToString("#,##0.00");
                lblDueTotal.Text = total.ToString("#,##0.00");
                GetCartTotal();
                // Enable/disable payment button
                btnSettlePayment.Enabled = hasrecord;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        public void GetCartTotal()
        {

            
            double sales = Double.Parse(lblSubTotal.Text);
           double totalDiscount = Double.Parse(lblDiscount.Text);
            double vat = sales * dbcon.GetVat();          

            lblVat.Text = vat.ToString("#,##0.00");
            double vatable = vat + sales;
           
           lblDisplayTotal.Text = vatable.ToString("#,##0.00");
           lblDueTotal.Text = vatable.ToString("#,##0.00");
        }
   


        public string GetProductIdFromCart(string cartId)
        {
            string productId = "";
            try
            {
                using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                {
                    connection.Open();
                    using (SqlCommand cm = new SqlCommand("SELECT ProductId FROM tblCart WHERE CartId = @CartId", connection))
                    {
                        cm.Parameters.AddWithValue("@CartId", cartId);
                        object result = cm.ExecuteScalar();
                        if (result != null)
                            productId = result.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            return productId;
        }
     

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

                string ColName = dataGridView2.Columns[e.ColumnIndex].Name;
                string cellValue = dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();

                if (ColName == "ColDelete") // Handle delete button column
                {
                    if (MessageBox.Show("Remove item from the cart?", stitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        string cartId = dataGridView2.Rows[e.RowIndex].Cells[1].Value.ToString();

                        using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                        {
                            connection.Open();
                            using (SqlCommand cm = new SqlCommand("DELETE FROM tblCart WHERE CartId = @CartId", connection))
                            {
                                cm.Parameters.AddWithValue("@CartId", cartId);
                                cm.ExecuteNonQuery();
                            }
                        }

                        MessageBox.Show("Item has been successfully removed!", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadCart(); // Refresh cart
                    }
                }
                else if (cellValue == "[ + ]") // Handle Add quantity button
                {
                    string cartId = dataGridView2.Rows[e.RowIndex].Cells["dgvSrID"].Value.ToString();
                    string productId = GetProductIdFromCart(cartId);
                    int currentQty = int.Parse(dataGridView2.Rows[e.RowIndex].Cells["dgvQty"].Value.ToString());

                    // Check stock availability (sum across all stock-in records and subtract cart quantities)
                    using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                    {
                        connection.Open();
                        using (SqlCommand cm = new SqlCommand(@"
                    SELECT 
                        ISNULL(SUM(s.StockInQty), 0) - ISNULL(SUM(c.Qty), 0) AS AvailableStock
                    FROM tblStockIn s
                    LEFT JOIN tblCart c ON s.ProductId = c.ProductId
                    WHERE s.ProductId = @ProductId", connection))
                        {
                            cm.Parameters.AddWithValue("@ProductId", productId);
                            object result = cm.ExecuteScalar();
                            int availableStock = result != null ? Convert.ToInt32(result) : 0;

                            if (currentQty < availableStock)
                            {
                                using (SqlCommand updateCmd = new SqlCommand(
                                    "UPDATE tblCart SET Qty = Qty + 1, LineTotal = Price * (Qty + 1) WHERE CartId = @CartId",
                                    connection))
                                {
                                    updateCmd.Parameters.AddWithValue("@CartId", cartId);
                                    updateCmd.ExecuteNonQuery();
                                }
                                LoadCart(); // Refresh cart
                            }
                            else
                            {
                                MessageBox.Show("Remaining quantity on hand is '" + availableStock + "'!",
                                    "Out of Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                else if (cellValue == "[ - ]") // Handle Subtract quantity button
                {
                    string cartId = dataGridView2.Rows[e.RowIndex].Cells["dgvSrID"].Value.ToString();
                    int currentQty = int.Parse(dataGridView2.Rows[e.RowIndex].Cells["dgvQty"].Value.ToString());

                    if (currentQty > 1)
                    {
                        using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                        {
                            connection.Open();
                            using (SqlCommand cm = new SqlCommand("UPDATE tblCart SET Qty = Qty - 1, LineTotal = Price * (Qty - 1) WHERE CartId = @CartId", connection))
                            {
                                cm.Parameters.AddWithValue("@CartId", cartId);
                                cm.ExecuteNonQuery();
                            }
                        }
                        LoadCart(); // Refresh cart
                    }
                    else
                    {
                        if (MessageBox.Show("Remove item from the cart?", stitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            using (SqlConnection connection = new SqlConnection(dbcon.MyConnection()))
                            {
                                connection.Open();
                                using (SqlCommand cm = new SqlCommand("DELETE FROM tblCart WHERE CartId = @CartId", connection))
                                {
                                    cm.Parameters.AddWithValue("@CartId", cartId);
                                    cm.ExecuteNonQuery();
                                }
                            }
                            MessageBox.Show("Item has been successfully removed!", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadCart(); // Refresh cart
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

    

        }


       

        private void txt_Search_KeyDown(object sender, KeyEventArgs e)
        {
           // string psearch = txt_Search.Text;
            //SearchProduct(psearch);
           // LoadCart();
           
        }

        private void frmSales_Load(object sender, EventArgs e)
        {
            NotifyExpiringProduct();
          //  calculate_populate_Labels();
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            frmLookUp frm = new frmLookUp(this);
            frm.ShowDialog();
        }

        private void btnDailySales_Click(object sender, EventArgs e)
        {
            frmSalesHistory frm = new frmSalesHistory();
            frm.dt1.Enabled = false;
            frm.dt2.Enabled = false;
          //  frm.suser = lblName.Text;
            frm.suser = lblUser.Text;
            frm.cboCashier.Enabled = false;
            frm.cboCashier.Text = lblUser.Text;
            frm.ShowDialog();

            
        }

        private void btnSettlePayment_Click(object sender, EventArgs e)
        {
            frmSettlePayment frm = new frmSettlePayment(this);
            frm.txtFinalTotal.Text = lblDisplayTotal.Text;
            frm.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView2.Rows.Count > 0)
            {
                MessageBox.Show("Unable to logout. Please cancel all the transactions.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (MessageBox.Show("LOGOUT THE APPLICATION ?", "CONFIRM", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                this.Hide();
                frmLogInForm frm = new frmLogInForm();
                frm.ShowDialog();
            }
        }

        private void btnDiscount_Click(object sender, EventArgs e)
        {
            frmDiscount frm = new frmDiscount(this);
           // frm.lblDiscountID.Text = dbcon.GetDiscountValue().ToString();
            frm.lblDiscountID.Text = id;
            frm.txtPrice.Text = price;
           
            frm.txt_discount.Focus();
            frm.ShowDialog();
        }

        

        private void lblDiscount_Click(object sender, EventArgs e)
        {
          
          
        }

        private void dataGridView2_SelectionChange(object sender, EventArgs e)
        {
            // Load Discount 
            int i = dataGridView2.CurrentRow.Index;
            id = dataGridView2[1, i].Value.ToString();
            price = dataGridView2["dgvTotal", i].Value.ToString();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Remove all items from the cart ?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                cn.Open();
                cm = new SqlCommand("delete from tblCart where InvoiceNo like '" + lblIvoiceNo.Text + "'", cn);
                cm.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("All items has been successfully remove!", "Remove items", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadCart();
            }
        }




    }
}
