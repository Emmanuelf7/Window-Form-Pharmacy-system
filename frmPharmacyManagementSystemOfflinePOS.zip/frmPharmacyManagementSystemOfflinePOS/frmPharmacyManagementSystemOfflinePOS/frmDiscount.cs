﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmDiscount : Form
    {
         SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        frmSales flist;
        public frmDiscount(frmSales fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.flist=fm;
        }

        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Add Discount?", "Click yes to confirm.", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("update tblCart set Discount=@Discount where CartId=@CartId", cn);

                    cm.Parameters.AddWithValue("@Discount", txt_discount.Text);
                    cm.Parameters.AddWithValue("@CartId", lblDiscountID.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                  //  MessageBox.Show("Discount has been successfully updated!", "Discount updated", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    flist.LoadCart();
                    txtPrice.Clear();
                    txt_discount.Clear();
                    
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txt_discount_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double discount = Double.Parse(txtPrice.Text) - Double.Parse(txt_discount.Text);
                txtPrice.Text = discount.ToString("#,##0.00");
            }
            catch (Exception)
            {

                txtPrice.Text = "0";

            }
        }

        }
    }

