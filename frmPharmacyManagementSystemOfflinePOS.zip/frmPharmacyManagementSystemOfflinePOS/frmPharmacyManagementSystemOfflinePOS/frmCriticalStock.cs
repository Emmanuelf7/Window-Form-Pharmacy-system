﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmCriticalStock : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        public frmCriticalStock()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            LoadCriticalStock();
        }

        public void LoadCriticalStock()
        {
            try
            {
                int i = 0;
                dataGridView2.Rows.Clear();

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    string sql = @"
                SELECT 
                    p.ProductID,
                    b.Brand,
                    g.Generic,
                    c.Classification,
                    t.TypeName,
                    f.FormulationName,
                    ISNULL(SUM(si.StockInQty), 0) AS StockQty
                FROM tblProducts AS p
                INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
                INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
                INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
                INNER JOIN tblType AS t ON p.TypeId = t.TypeID
                INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
                LEFT JOIN tblStockIn AS si ON p.ProductID = si.ProductId
                GROUP BY 
                    p.ProductID, b.Brand, g.Generic, c.Classification, t.TypeName, f.FormulationName
                HAVING ISNULL(SUM(si.StockInQty), 0) <= 9
                ORDER BY StockQty ASC";   // Show lowest stock first

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            i++;
                            dataGridView2.Rows.Add(
                                i,
                                dr["ProductID"].ToString(),
                                dr["Brand"].ToString(),
                                dr["Generic"].ToString(),
                                dr["Classification"].ToString(),
                                dr["TypeName"].ToString(),
                                dr["FormulationName"].ToString(),
                                dr["StockQty"].ToString()
                            );
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading critical stock: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

    }
}
