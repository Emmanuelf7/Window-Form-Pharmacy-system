﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
       
    class DBConnection
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        SqlDataReader dr;
        public String strUser = "Emma";
        private string con;
        private int productline;
       
        public string MyConnection()
        {
            con = @"Data Source=(LocalDB)\v11.0;AttachDbFilename=|DataDirectory|\AppData\PharnacyMgtSystemPOSWDF.mdf; Initial Catalog=PharnacyMgtSystemPOSWDF;Integrated Security=True";
         // con = @"Data Source=EMMAPC\SQLEXPRESS;Initial Catalog=PharnacyMgtSystemPOSWDF;Integrated Security=True";
            return con;
        }

        public double ExpiringProduct()
        {


            cn = new SqlConnection();
            cn.ConnectionString = con;
            cn.Open();
            cm = new SqlCommand("select count(*) as ExpiringProductCount from tblProducts where ExpiringDate <= DATEADD(day,90, GETDATE())", cn);
            productline = int.Parse(cm.ExecuteScalar().ToString());
            cn.Close();
            return productline;
        }

        public double GetVat()
        {
            double strVate = 0;
            cn.ConnectionString = MyConnection();
            cn.Open();
            cm = new SqlCommand("select * from tblVat", cn);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                strVate = Double.Parse(dr["Vat"].ToString());
            }
            else
            {
                strVate = Double.Parse("0.00");
            }
            dr.Close();
            cn.Close();
            return strVate;
        }
        public double ProductLine()
        {
            double productline = 0;

            try
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();

                    string sql = @"
                SELECT COUNT(*)
                FROM tblProducts AS p
                INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
                INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
                INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
                INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
                INNER JOIN tblType AS t ON p.TypeId = t.TypeID
                LEFT JOIN (
                    SELECT productId, SUM(StockInQty) AS TotalStockIn
                    FROM tblStockIn
                    GROUP BY productId
                ) AS si ON p.ProductID = si.productId";

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    {
                        productline = Convert.ToDouble(cm.ExecuteScalar());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error counting product lines: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return productline;
        }

        public double StockOnHand()
        {
            double stockonhand = 0;

            try
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();

                    string sql = @"select isnull(sum(StockInQty),0) as StockInQty from tblStockIn";

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    {
                        object result = cm.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            stockonhand = Convert.ToDouble(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating stock on hand: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return stockonhand;
        }

//        public double StockOnHand()
//        {
//            double stockonhand = 0;

//            try
//            {
//                using (SqlConnection cn = new SqlConnection(con))
//                {
//                    cn.Open();

//                    string sql = @"
//                SELECT ISNULL(SUM(p.Qty), 0) AS StockOnHand
//                FROM tblProducts AS p
//                INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
//                INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
//                INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
//                INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
//                INNER JOIN tblType AS t ON p.TypeId = t.TypeID
//                LEFT JOIN (
//                    SELECT productId, SUM(StockInQty) AS TotalStockIn
//                    FROM tblStockIn
//                    GROUP BY productId
//                ) AS si ON p.ProductID = si.productId";

//                    using (SqlCommand cm = new SqlCommand(sql, cn))
//                    {
//                        object result = cm.ExecuteScalar();
//                        if (result != null && result != DBNull.Value)
//                        {
//                            stockonhand = Convert.ToDouble(result);
//                        }
//                    }
//                }
//            }
//            catch (Exception ex)
//            {
//                MessageBox.Show("Error calculating stock on hand: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
//            }

//            return stockonhand;
//        }


        public double DailySales()
        {
            double dailysales = 0;

            try
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();

                    string sql = @"
                SELECT 
                    ISNULL(SUM(s.LineTotal), 0) AS TotalSales
                FROM tblSales s
                INNER JOIN tblSalesDetail sd ON s.InvoiceNo = sd.InvoiceNo
                LEFT JOIN tblBrand b ON s.BrandId = b.BrandID
                LEFT JOIN tblGeneric g ON s.GenericId = g.GenericID
                LEFT JOIN tblClassification c ON s.ClassificationId = c.ClassificationId
                LEFT JOIN tblType t ON s.TypeId = t.TypeID
                LEFT JOIN tblFormulation f ON s.FormulationId = f.FormulationID
                WHERE s.Qty > 0
                  AND CAST(sd.SalesDate AS DATE) = @sdate";  // filter by today

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    {
                        cm.Parameters.AddWithValue("@sdate", DateTime.Now.Date);

                        object result = cm.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            dailysales = Convert.ToDouble(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading daily sales: " + ex.Message,
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return dailysales;
        }

        public double CriticalStock()
        {
            double critical = 0;

            try
            {
                using (SqlConnection cn = new SqlConnection(con))
                {
                    cn.Open();

                    string sql = @"
                SELECT COUNT(*) 
                FROM (
                    SELECT ProductId, SUM(StockInQty) AS TotalStock
                    FROM tblStockIn
                    GROUP BY ProductId
                    HAVING SUM(StockInQty) <= 5
                ) AS CriticalProducts";

                    using (SqlCommand cm = new SqlCommand(sql, cn))
                    {
                        object result = cm.ExecuteScalar();
                        if (result != null && result != DBNull.Value)
                        {
                            critical = Convert.ToDouble(result);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error calculating critical stock: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return critical;
        }

            public string GetPassword(string user)
        {
            string password = "";
            cn.ConnectionString = MyConnection();
            cn.Open();
            cm = new SqlCommand("select * from tblUser where UserName=@username", cn);
            cm.Parameters.AddWithValue("@username", user);
            dr = cm.ExecuteReader();
            dr.Read();
            if (dr.HasRows)
            {
                password = dr["Password"].ToString();
            }
            dr.Close();
            cn.Close();
            return password;
        }
        }
    }

