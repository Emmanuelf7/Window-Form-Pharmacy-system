﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_StockIn : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        string stitle = "POS System";
        public frm_StockIn()
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }



        public void Loadproduct()
        {
            try
            {
                if (string.IsNullOrEmpty(txt_Search.Text))
                {
                    dataGridView1.Rows.Clear();
                    return;
                }

                int i = 0;
                dataGridView1.Rows.Clear();
                cn.Open();

                string query = @"
            SELECT 
                p.ProductID, 
                p.Barcode, 
                b.Brand, 
                g.Generic, 
                c.Classification, 
                t.TypeName, 
                f.FormulationName, 
                p.Qty, 
                ISNULL(si.TotalStockIn, 0) AS StockInQty, 
                p.CostPrice, 
                p.SellingPrice, 
                p.Profit
            FROM tblProducts AS p
            INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
            INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
            INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
            INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
            INNER JOIN tblType AS t ON p.TypeId = t.TypeID
            LEFT JOIN (
                SELECT productId, SUM(StockInQty) AS TotalStockIn
                FROM tblStockIn
                GROUP BY productId
            ) AS si ON p.ProductID = si.productId
            WHERE g.Generic LIKE @SearchTerm OR b.Brand LIKE @SearchTerm
            ORDER BY p.ProductID";

                using (SqlCommand cm = new SqlCommand(query, cn))
                {
                    cm.Parameters.AddWithValue("@SearchTerm", "%" + txt_Search.Text + "%");

                    using (SqlDataReader dr = cm.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            i++;
                            dataGridView1.Rows.Add(
                                i,
                                dr["ProductID"].ToString(),
                                dr["Barcode"].ToString(),
                                dr["Brand"].ToString(),
                                dr["Generic"].ToString(),
                                dr["Classification"].ToString(),
                                dr["TypeName"].ToString(),
                                dr["FormulationName"].ToString(),
                                dr["Qty"].ToString(),
                                dr["StockInQty"].ToString(),
                                dr["CostPrice"].ToString(),
                                dr["SellingPrice"].ToString(),
                                dr["Profit"].ToString()
                            );
                        }
                    }
                }

                cn.Close();
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



       

        private void cmbo_Filter_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void txt_Search_TextChanged(object sender, EventArgs e)
        {
            Loadproduct();
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                if (txt_ReferenceNo.Text == String.Empty)
                {
                    MessageBox.Show("Please generate reference number", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txt_ReferenceNo.Focus();
                    return;
                }
                if (txt_Received.Text == String.Empty)
                {
                    MessageBox.Show("Please enter received by name", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txt_Received.Focus();
                    return;
                }

                string ColName = dataGridView1.Columns[e.ColumnIndex].Name;
          
                if (ColName == "ColSelect")
                {
                    if (MessageBox.Show("Add this item", stitle, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                        // Add all the necessary columns to dataGridView2
                        dataGridView2.Rows.Add(
                            selectedRow.Cells[1].Value,  // ProductID (assuming column 1)
                            selectedRow.Cells[2].Value,  // Barcode
                            selectedRow.Cells[3].Value,  // Brand
                            selectedRow.Cells[4].Value,  // Generic
                            selectedRow.Cells[5].Value,  // Classification
                            selectedRow.Cells[6].Value,  // TypeName
                            selectedRow.Cells[7].Value,  // FormulationName  <-- This was missing
                            "0",  // Qty (initial quantity, will be updated by user)
                            selectedRow.Cells[9].Value,  // CostPrice
                            selectedRow.Cells[10].Value  // SellingPrice
                        );

                        MessageBox.Show("Successfully added", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Ignore header clicks or invalid indexes
                if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

                DataGridViewRow row = dataGridView2.Rows[e.RowIndex];

                // Ensure the Qty column (dgvQty) is not null or empty
                if (row.Cells["dgvQty"].Value != null &&
                    !string.IsNullOrEmpty(row.Cells["dgvQty"].Value.ToString()))
                {
                    int stock;
                    if (int.TryParse(row.Cells["dgvQty"].Value.ToString(), out stock))
                    {
                        txt_Count.Text = stock.ToString();
                    }
                    else
                    {
                        txt_Count.Text = "0"; // fallback if parsing fails
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //int i = 0;
            //int Stock = 0;
            //if(dataGridView2.Rows[i].Cells[7].Value.ToString()==String.Empty){
            //    Stock = int.Parse(dataGridView2.Rows[i].Cells[7].ToString());
            //    txt_Count.Text = Stock.ToString();
            //}
                
        }

        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView2.Rows.Count == 0)
                {
                    MessageBox.Show("Please add items to stock first", stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string sdate = dtDate.Value.ToString("yyyy-MM-dd");
                bool added_stock = false;
                int successCount = 0;

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    foreach (DataGridViewRow row in dataGridView2.Rows)
                    {
                        if (row.IsNewRow) continue;

                        int quantity = 0;
                        int productId = 0;

                        // ✅ CORRECTED: Using the actual column names from your DataGridView
                        object qtyCell = row.Cells["dgvQty"].Value;
                        object productIdCell = row.Cells["dgvProductID"].Value; // Correct ProductID column
                        object productNameCell = row.Cells["dgvBrand_Name"].Value; // Using Brand as product name

                        string productName = productNameCell != null ? productNameCell.ToString() : "Unknown";

                        // 1. Quantity validation
                        if (qtyCell == null || string.IsNullOrWhiteSpace(qtyCell.ToString()))
                        {
                            MessageBox.Show("Please input quantity for product: " + productName, stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }

                        if (!int.TryParse(qtyCell.ToString().Trim(), out quantity) || quantity <= 0)
                        {
                            MessageBox.Show("Please enter a valid quantity (positive number) for product: " + productName, stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }

                        // 2. Product ID validation - Using correct column name
                        if (productIdCell == null || string.IsNullOrWhiteSpace(productIdCell.ToString()))
                        {
                            MessageBox.Show("Invalid product ID for product: " + productName, stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }

                        if (!int.TryParse(productIdCell.ToString(), out productId))
                        {
                            MessageBox.Show("Invalid product ID format for product: " + productName + ". Value: " + productIdCell, stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }

                        // 3. Check if product exists in tblProducts
                        bool productExists = false;
                        using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM tblProducts WHERE ProductID = @ProductID", cn))
                        {
                            checkCmd.Parameters.AddWithValue("@ProductID", productId);
                            int count = (int)checkCmd.ExecuteScalar();
                            productExists = (count > 0);
                        }

                        if (!productExists)
                        {
                            MessageBox.Show("Product ID " + productId + " does not exist in the product database. Please check the product ID.", stitle, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            continue;
                        }

                        // 4. Check for duplicate entry in tblStockIn
                        using (SqlCommand cm = new SqlCommand(@"SELECT COUNT(*) 
                                                       FROM tblStockIn 
                                                       WHERE ReferenceNo = @ReferenceNo 
                                                       AND productId = @productId 
                                                       AND Sdate = @Sdate", cn))
                        {
                            cm.Parameters.AddWithValue("@ReferenceNo", txt_ReferenceNo.Text);
                            cm.Parameters.AddWithValue("@productId", productId);
                            cm.Parameters.AddWithValue("@Sdate", sdate);

                            int existingCount = (int)cm.ExecuteScalar();

                            if (existingCount > 0)
                            {
                                MessageBox.Show("Product " + productName + " already exists in stock for this reference number", stitle, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                continue;
                            }
                        }

                        // 5. Insert into tblStockIn
                        using (SqlCommand cmd = new SqlCommand(@"INSERT INTO tblStockIn(ReferenceNo, ReceivedBy, productId, StockInQty, Sdate) 
                                                         VALUES(@ReferenceNo, @ReceivedBy, @productId, @StockInQty, @Sdate)", cn))
                        {
                            cmd.Parameters.AddWithValue("@ReferenceNo", txt_ReferenceNo.Text);
                            cmd.Parameters.AddWithValue("@ReceivedBy", txt_Received.Text);
                            cmd.Parameters.AddWithValue("@productId", productId);
                            cmd.Parameters.AddWithValue("@StockInQty", quantity);
                            cmd.Parameters.AddWithValue("@Sdate", sdate);

                            cmd.ExecuteNonQuery();
                        }

                        // 6. Update tblProducts stock
                        //using (SqlCommand cmd = new SqlCommand("UPDATE tblProducts SET Qty = Qty + @Qty WHERE ProductID = @ProductID", cn))
                        //{
                        //    cmd.Parameters.AddWithValue("@Qty", quantity);
                        //    cmd.Parameters.AddWithValue("@ProductID", productId);

                        //    cmd.ExecuteNonQuery();
                        //}

                        successCount++;
                        added_stock = true;
                    }

                    cn.Close();
                }

                // Final result messages
                if (added_stock)
                {
                    MessageBox.Show(successCount + " stock item(s) have been successfully added", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    dataGridView2.Rows.Clear();
                    txt_ReferenceNo.Text = "";
                    txt_Received.Text = "";
                }
                else
                {
                    MessageBox.Show("No items were added to stock", stitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, stitle, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }








        private void button1_Click(object sender, EventArgs e)
        {
            txt_Received.Clear();
            txt_ReferenceNo.Clear();
            dataGridView2.Rows.Clear();

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Random rnd = new Random();
            txt_ReferenceNo.Clear();
            txt_ReferenceNo.Text += rnd.Next();
        }

        public void LoadStockInHistory()
        {
            try
            {
                DateTime sdate1 = dateTimePicker1.Value.Date;
                DateTime sdate2 = dateTimePicker2.Value.Date;

                int i = 0;
                dataGridView3.Rows.Clear();

                using (SqlConnection cn = new SqlConnection(dbcon.MyConnection()))
                {
                    cn.Open();

                    string query = @"
                SELECT 
                    s.StockId, 
                    s.ReferenceNo, 
                    s.ReceivedBy, 
                    s.StockInQty,        -- Make sure this column exists in tblStockIn
                    s.Sdate,
                    b.Brand, 
                    g.Generic, 
                    c.Classification, 
                    t.TypeName, 
                    f.FormulationName
                FROM tblStockIn AS s
                INNER JOIN tblProducts AS p ON s.productId = p.ProductID
                INNER JOIN tblBrand AS b ON p.BrandId = b.BrandID
                INNER JOIN tblClassification AS c ON p.ClassificationId = c.ClassificationId
                INNER JOIN tblFormulation AS f ON p.FormulationId = f.FormulationID
                INNER JOIN tblGeneric AS g ON p.GenericId = g.GenericID
                INNER JOIN tblType AS t ON p.TypeId = t.TypeID
                WHERE CAST(s.Sdate AS DATE) BETWEEN @StartDate AND @EndDate
                ORDER BY s.StockId";

                    using (SqlCommand cm = new SqlCommand(query, cn))
                    {
                        cm.Parameters.AddWithValue("@StartDate", sdate1);
                        cm.Parameters.AddWithValue("@EndDate", sdate2);

                        using (SqlDataReader dr = cm.ExecuteReader())
                        {
                            while (dr.Read())
                            {
                                i++;
                                DateTime stockDate = Convert.ToDateTime(dr["Sdate"]);
                                string formattedDate = stockDate.ToString("dd-MM-yyyy");

                                // Handle StockInQty safely (in case it’s NULL)
                                string stockQty = dr["StockInQty"] != DBNull.Value
                                                  ? dr["StockInQty"].ToString()
                                                  : "0";

                                dataGridView3.Rows.Add(
                                    i,                                  // Serial #
                                    dr["StockId"].ToString(),          // Column 1
                                    dr["ReferenceNo"].ToString(),      // Column 2
                                    dr["ReceivedBy"].ToString(),       // Column 3
                                    dr["Brand"].ToString(),            // Column 4
                                    dr["Generic"].ToString(),          // Column 5
                                    dr["Classification"].ToString(),   // Column 6
                                    dr["TypeName"].ToString(),         // Column 7
                                    dr["FormulationName"].ToString(),  // Column 8
                                    stockQty,                          // Column 9 (StockInQty)
                                    formattedDate                      // Column 10 (Sdate)
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading stock history: " + ex.Message, "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void button2_Click(object sender, EventArgs e)
        {
            LoadStockInHistory();
        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }

        private void frm_StockIn_Load(object sender, EventArgs e)
        {
            // Populate the filter combobox
            cmbo_Filter.Items.AddRange(new string[] { 
         "Brand", "Generic", "Classification", "Type", "Formulation" 
    });
            cmbo_Filter.SelectedIndex = 0; // Select first item by default
        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
