﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_Product : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmProductList fm;
        public decimal profit = 0;
        public frm_Product(frmProductList flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm = flist;
            loadBrand();
            loadGenericName();
            loadClassification();
            loadType();
            loadFormulation();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void loadBrand()
        {

            SqlConnection con = new SqlConnection(dbcon.MyConnection());
            SqlCommand com = new SqlCommand("Select Brand from tblBrand", con);
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            //AutoCompleteStringCollection Contains a collection of strings to use for the auto-complete feature on certain Windows Forms controls.  
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            while (rdr.Read())
            {
                autoCompleteCollection.Add(rdr.GetString(0));
            }
            //Set AutoCompleteSource property of txt_StateName as CustomSource  
            txt_Brand.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //Set AutoCompleteMode property of txt_StateName as SuggestAppend. SuggestAppend Applies both Suggest and Append  
            txt_Brand.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_Brand.AutoCompleteCustomSource = autoCompleteCollection;
            con.Close();

        }

        private void loadGenericName()
        {

            SqlConnection con = new SqlConnection(dbcon.MyConnection());
            SqlCommand com = new SqlCommand("Select Generic from tblGeneric", con);
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            //AutoCompleteStringCollection Contains a collection of strings to use for the auto-complete feature on certain Windows Forms controls.  
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            while (rdr.Read())
            {
                autoCompleteCollection.Add(rdr.GetString(0));
            }
            //Set AutoCompleteSource property of txt_StateName as CustomSource  
            txt_Generic.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //Set AutoCompleteMode property of txt_StateName as SuggestAppend. SuggestAppend Applies both Suggest and Append  
            txt_Generic.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_Generic.AutoCompleteCustomSource = autoCompleteCollection;
            con.Close();

        }

        private void loadClassification()
        {

            SqlConnection con = new SqlConnection(dbcon.MyConnection());
            SqlCommand com = new SqlCommand("Select Classification from tblClassification", con);
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            //AutoCompleteStringCollection Contains a collection of strings to use for the auto-complete feature on certain Windows Forms controls.  
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            while (rdr.Read())
            {
                autoCompleteCollection.Add(rdr.GetString(0));
            }
            //Set AutoCompleteSource property of txt_StateName as CustomSource  
            txt_Classification.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //Set AutoCompleteMode property of txt_StateName as SuggestAppend. SuggestAppend Applies both Suggest and Append  
            txt_Classification.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_Classification.AutoCompleteCustomSource = autoCompleteCollection;
            con.Close();

        }

        private void loadType()
        {

            SqlConnection con = new SqlConnection(dbcon.MyConnection());
            SqlCommand com = new SqlCommand("Select TypeName from tblType", con);
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            //AutoCompleteStringCollection Contains a collection of strings to use for the auto-complete feature on certain Windows Forms controls.  
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            while (rdr.Read())
            {
                autoCompleteCollection.Add(rdr.GetString(0));
            }
            //Set AutoCompleteSource property of txt_StateName as CustomSource  
            txt_Type.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //Set AutoCompleteMode property of txt_StateName as SuggestAppend. SuggestAppend Applies both Suggest and Append  
            txt_Type.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_Type.AutoCompleteCustomSource = autoCompleteCollection;
            con.Close();

        }

        private void loadFormulation()
        {

            SqlConnection con = new SqlConnection(dbcon.MyConnection());
            SqlCommand com = new SqlCommand("Select FormulationName from tblFormulation", con);
            con.Open();
            SqlDataReader rdr = com.ExecuteReader();
            //AutoCompleteStringCollection Contains a collection of strings to use for the auto-complete feature on certain Windows Forms controls.  
            AutoCompleteStringCollection autoCompleteCollection = new AutoCompleteStringCollection();
            while (rdr.Read())
            {
                autoCompleteCollection.Add(rdr.GetString(0));
            }
            //Set AutoCompleteSource property of txt_StateName as CustomSource  
            txt_Formulation.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //Set AutoCompleteMode property of txt_StateName as SuggestAppend. SuggestAppend Applies both Suggest and Append  
            txt_Formulation.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txt_Formulation.AutoCompleteCustomSource = autoCompleteCollection;
            con.Close();

        }

        private void txt_Brand_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Clear the label when search text changes
                lblBrand.Text = string.Empty;

                cn.Open();
                cm = new SqlCommand("select * from tblBrand where Brand like @Brand", cn);
                cm.Parameters.AddWithValue("@Brand", "%" + txt_Brand.Text + "%");
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    if (lblBrand.Text.Trim() == string.Empty)
                    {
                        lblBrand.Text = dr[0].ToString();
                    }
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                if (dr != null && !dr.IsClosed)
                {
                    dr.Close();
                }
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txt_Generic_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Clear the label when search text changes
                lblGeneric.Text = string.Empty;

                cn.Open();
                cm = new SqlCommand("select * from tblGeneric where Generic like @Generic", cn);
                cm.Parameters.AddWithValue("@Generic", "%" + txt_Generic.Text + "%");
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    if (lblGeneric.Text.Trim() == string.Empty)
                    {
                        lblGeneric.Text = dr[0].ToString();
                    }
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                if (dr != null && !dr.IsClosed)
                {
                    dr.Close();
                }
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void txt_Classification_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Clear the label when search text changes
                lblClassification.Text = string.Empty;

                cn.Open();
                cm = new SqlCommand("select * from tblClassification where Classification like @Classification", cn);
                cm.Parameters.AddWithValue("@Classification", "%" + txt_Classification.Text + "%");
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    if (lblClassification.Text.Trim() == string.Empty)
                    {
                        lblClassification.Text = dr[0].ToString();
                    }
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                if (dr != null && !dr.IsClosed)
                {
                    dr.Close();
                }
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txt_Type_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Clear the label when search text changes
                lblType.Text = string.Empty;

                cn.Open();
                cm = new SqlCommand("select * from tblType where TypeName like @TypeName", cn);
                cm.Parameters.AddWithValue("@TypeName", "%" + txt_Type.Text + "%");
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    if (lblType.Text.Trim() == string.Empty)
                    {
                        lblType.Text = dr[0].ToString();
                    }
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                if (dr != null && !dr.IsClosed)
                {
                    dr.Close();
                }
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txt_Formulation_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // Clear the label when search text changes
                lblFormulation.Text = string.Empty;

                cn.Open();
                cm = new SqlCommand("select * from tblFormulation where FormulationName like @FormulationName", cn);
                cm.Parameters.AddWithValue("@FormulationName", "%" + txt_Formulation.Text + "%");
                dr = cm.ExecuteReader();

                while (dr.Read())
                {
                    if (lblFormulation.Text.Trim() == string.Empty)
                    {
                        lblFormulation.Text = dr[0].ToString();
                    }
                }

                dr.Close();
                cn.Close();
            }
            catch (Exception ex)
            {
                if (dr != null && !dr.IsClosed)
                {
                    dr.Close();
                }
                if (cn.State == ConnectionState.Open)
                {
                    cn.Close();
                }
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Clear()
        {
            txt_Barcode.Text = string.Empty;
            lblBrand.Text = string.Empty;
            lblGeneric.Text = string.Empty;
            lblClassification.Text = string.Empty;
            lblType.Text = string.Empty;
            lblFormulation.Text = string.Empty;
            txt_InitialQtyLevel.Text = string.Empty;
            txt_CostPrice.Text = string.Empty;
            txt_SellingPrice.Text = string.Empty;
            dtExpiringDate.Value = DateTime.Now;
            txt_Generic.Text = string.Empty; // Th

            txt_Barcode.Focus();
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to save this product?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    decimal profit = Convert.ToDecimal(txt_SellingPrice.Text) - Convert.ToDecimal(txt_CostPrice.Text);
                    cn.Open();
                    cm = new SqlCommand("INSERT INTO tblProducts(Barcode,BrandId,GenericId,ClassificationId,TypeId,FormulationId,Qty,CostPrice,SellingPrice,Profit,ExpiringDate)VALUES(@Barcode,@BrandId,@GenericId,@ClassificationId,@TypeId,@FormulationId,@Qty,@CostPrice,@SellingPrice,@Profit,@ExpiringDate)", cn);
                    cm.Parameters.AddWithValue("@Barcode", txt_Barcode.Text);
                    cm.Parameters.AddWithValue("@BrandId", int.Parse(lblBrand.Text));
                    cm.Parameters.AddWithValue("@GenericId", int.Parse(lblGeneric.Text));
                    cm.Parameters.AddWithValue("@ClassificationId", int.Parse(lblClassification.Text));
                    cm.Parameters.AddWithValue("@TypeId", int.Parse(lblType.Text));
                    cm.Parameters.AddWithValue("@FormulationId", int.Parse(lblFormulation.Text));
                    cm.Parameters.AddWithValue("@Qty", int.Parse(txt_InitialQtyLevel.Text));
                    cm.Parameters.AddWithValue("@CostPrice", Convert.ToDecimal(txt_CostPrice.Text));
                    cm.Parameters.AddWithValue("@SellingPrice", Convert.ToDecimal(txt_SellingPrice.Text));
                    cm.Parameters.AddWithValue("@Profit", Convert.ToDecimal(profit));
                    cm.Parameters.AddWithValue("@ExpiringDate", dtExpiringDate.Value);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Product has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    
                    Clear();
                    fm.LoadProducts();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
              try
            {
                if (MessageBox.Show("Please confirm if you want to update this product?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    decimal profit = Convert.ToDecimal(txt_SellingPrice.Text) - Convert.ToDecimal(txt_CostPrice.Text);
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblProducts SET Barcode=@Barcode,BrandId=@BrandId,GenericId=@GenericId,ClassificationId=@ClassificationId,TypeId=@TypeId,FormulationId=@FormulationId,Qty=@Qty,CostPrice=@CostPrice,SellingPrice=@SellingPrice,Profit=@Profit, ExpiringDate=@ExpiringDate where ProductID like @ProductID", cn);
                    cm.Parameters.AddWithValue("@ProductID", lblProductID.Text);
                    cm.Parameters.AddWithValue("@Barcode", txt_Barcode.Text);
                    cm.Parameters.AddWithValue("@BrandId", int.Parse(lblBrand.Text));
                    cm.Parameters.AddWithValue("@GenericId", int.Parse(lblGeneric.Text));
                    cm.Parameters.AddWithValue("@ClassificationId", int.Parse(lblClassification.Text));
                    cm.Parameters.AddWithValue("@TypeId", int.Parse(lblType.Text));
                    cm.Parameters.AddWithValue("@FormulationId", int.Parse(lblFormulation.Text));
                    cm.Parameters.AddWithValue("@Qty", int.Parse(txt_InitialQtyLevel.Text));
                    cm.Parameters.AddWithValue("@CostPrice", Convert.ToDecimal(txt_CostPrice.Text));
                    cm.Parameters.AddWithValue("@SellingPrice", Convert.ToDecimal(txt_SellingPrice.Text));
                    cm.Parameters.AddWithValue("@Profit", Convert.ToDecimal(profit));
                    cm.Parameters.AddWithValue("@ExpiringDate", dtExpiringDate.Value);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Product has been successfully updated!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                    Clear();
                    fm.LoadProducts();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
            txt_Barcode.Clear();
            txt_Brand.Clear();
            txt_Generic.Clear();
            txt_Classification.Clear();
            txt_Type.Clear();
            txt_Formulation.Clear();
            txt_InitialQtyLevel.Clear();
            txt_CostPrice.Clear();
            txt_SellingPrice.Clear();

            txt_Barcode.Focus();
       
        }
        }
        }
        
    

