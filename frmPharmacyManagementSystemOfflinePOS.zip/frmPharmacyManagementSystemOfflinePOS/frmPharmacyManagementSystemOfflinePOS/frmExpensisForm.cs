﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frmExpensisForm : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        frmExpensisList f;
        public frmExpensisForm(frmExpensisList fm)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            f = fm;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
            txt_Description.Clear();
            txtAmount.Clear();
            txtReason.Clear();
            txt_Description.Focus();
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
            try
            {

                if (string.IsNullOrWhiteSpace(txt_Description.Text) ||
                    string.IsNullOrWhiteSpace(txtAmount.Text) ||
                    string.IsNullOrWhiteSpace(txtReason.Text))
                {
                    MessageBox.Show("Missing Information !!!");
                    return;
                }
                cn.Open();
                cm = new SqlCommand("INSERT INTO tblExpensis(SDate, Description, Amount, Reason)VALUES(@SDate, @Description, @Amount, @Reason)", cn);
                cm.Parameters.AddWithValue("@SDate", dtDate.Value.ToString("dd-MM-yyyy"));
                cm.Parameters.AddWithValue("@Description", txt_Description.Text);

                decimal Amount;

                if (!decimal.TryParse(txtAmount.Text, out Amount))
                {
                    MessageBox.Show("Amount must be numeric values.");
                    return;
                }
                cm.Parameters.AddWithValue("Amount", Convert.ToDouble(txtAmount.Text));
                cm.Parameters.AddWithValue("Reason", txtReason.Text);
                cm.ExecuteNonQuery();
                cn.Close();
                MessageBox.Show("Expensis has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                f.getAllExpensisRecord();
                Clear();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update this expensis?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblExpensis SET SDate=@SDate, Description=@Description, Amount=@Amount, Reason=@Reason where ExpensisId like'" + lblID.Text + "'", cn);
                    cm.Parameters.AddWithValue("@SDate", dtDate.Value.ToString("dd-MM-yyyy"));
                    cm.Parameters.AddWithValue("@Description", txt_Description.Text);
                    cm.Parameters.AddWithValue("@Amount", Convert.ToDouble(txtAmount.Text));
                    cm.Parameters.AddWithValue("@Reason", txtReason.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    f.getAllExpensisRecord();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }
    }
}