﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_Formulation : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmMaintenance fm;
        public frm_Formulation(frmMaintenance flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm = flist;
        }

        private void Clear()
        {
            txt_Formulation.Clear();
            txt_Formulation.Focus();
            return;
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
           
            try
            {
                bool found = false;
                cn.Open();
                cm = new SqlCommand("select * from tblFormulation where FormulationName like @FormulationName", cn);
                cm.Parameters.AddWithValue("@FormulationName", "%" + txt_Formulation.Text + "%");
                dr = cm.ExecuteReader(); // Initialize the SqlDataReader here
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        found = true;
                    }
                }
                dr.Close();
                cn.Close();
                if (found == false)
                {
                    if (MessageBox.Show("Please confirm if you want to save this formulation?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("INSERT INTO tblFormulation(FormulationName) VALUES(@FormulationName)", cn);
                        cm.Parameters.AddWithValue("@FormulationName", txt_Formulation.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        fm.LoadFormulation();
                        Clear();
                        MessageBox.Show("Formulation name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Error: Duplicate entry!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
               
            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }




            //    if (MessageBox.Show("Please confirm if you want to save this formulation?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            //    {
            //        cn.Open();
            //        cm = new SqlCommand("INSERT INTO tblFormulation(FormulationName)VALUES(@FormulationName)", cn);
            //        cm.Parameters.AddWithValue("@FormulationName", txt_Formulation.Text);
            //        cm.ExecuteNonQuery();
            //        cn.Close();
            //        MessageBox.Show("Formulation name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //        Clear();
            //        fm.LoadFormulation();
            //        //this.Dispose();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message);
         //   }
        

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdateCategory_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update this formulation?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblFormulation SET FormulationName=@FormulationName where FormulationID like '" + lblFormulation.Text + "'", cn);
                    cm.Parameters.AddWithValue("@FormulationName", txt_Formulation.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Formulation has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);                    
                    Clear();
                    fm.LoadFormulation();
                    this.Dispose();
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
