﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmPharmacyManagementSystemOfflinePOS
{
    public partial class frm_Classification : Form
    {
        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnection dbcon = new DBConnection();
        SqlDataReader dr;
        frmMaintenance fm;
        public frm_Classification(frmMaintenance flist)
        {
            InitializeComponent();
            cn = new SqlConnection(dbcon.MyConnection());
            this.fm= flist;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Clear()
        {
           txt_Category.Clear();
            txt_Category.Focus();
            return;
        }
        private void btn_CreateNew_Click(object sender, EventArgs e)
        {
          
            try
            {
                bool found = false;
                cn.Open();
                cm = new SqlCommand("select * from tblClassification where Classification like @Classification", cn);
                cm.Parameters.AddWithValue("@Classification", "%" + txt_Category.Text + "%");
                dr = cm.ExecuteReader(); // Initialize the SqlDataReader here
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        found = true;
                    }
                }
                dr.Close();
                cn.Close();
                if (found == false)
                {
                    if (MessageBox.Show("Please confirm if you want to save this classification?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        cn.Open();
                        cm = new SqlCommand("INSERT INTO tblClassification(Classification) VALUES(@Classification)", cn);
                        cm.Parameters.AddWithValue("@Classification", txt_Category.Text);
                        cm.ExecuteNonQuery();
                        cn.Close();
                        Clear();
                        fm.LoadClassification();
                        MessageBox.Show("Classification name has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Error: Duplicate entry!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }


            }
            catch (Exception ex)
            {
                cn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Please confirm if you want to update this classification?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    cn.Open();
                    cm = new SqlCommand("UPDATE tblClassification SET Classification=@Classification where ClassificationId like '" + lblCategoryId.Text + "'", cn);
                    cm.Parameters.AddWithValue("@Classification", txt_Category.Text);
                  //  cm.Parameters.AddWithValue("@CategoryId", lblCategoryId.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("Classification has been successfully saved!", "POS", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Clear();
                    fm.LoadClassification();
                    this.Dispose();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        }


    }

